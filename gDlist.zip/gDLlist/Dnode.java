/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gDLlist;

/**
 *
 * @author a
 */
public class Dnode<t> {
 private  Student studen_data;//هذا كأنك تقول private string data;
 //بس هذا كلاس student   يلاوجد فيه قيم عديدة 
 private Dnode next;
 private Dnode prve;
// الكنوستركتر 
 public Dnode(){
 next=prve=null;
 studen_data=null;
 }

    public Dnode(Student studen_data) {//تستقبل قيم من نوع كلاس 
        this();
        this.studen_data = studen_data;
    }

    public Student getStuden_data() {
        return studen_data;
    }

    public void setStuden_data(Student studen_data) {
        this.studen_data = studen_data;
    }

    public Dnode getNext() {
        return next;
    }

    public void setNext(Dnode next) {
        this.next = next;
    }

    public Dnode getPrve() {
        return prve;
    }

    public void setPrve(Dnode prve) {
        this.prve = prve;
    }

    @Override
    public String toString() {
        return "Dnode{" + "" + studen_data + '}';
    }




}
//