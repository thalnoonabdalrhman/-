
package gDLlist;

//الأقسام والمستويات ثابته 

import java.util.Objects;

enum DEPRTEMENT{
SE,//0
IT,
//1
COM,//2
AIDS,
CNC ,
MRE ,
IMDE ,
RE ,
//تحجز فيه كانه رقم 
}

//المستويات 
enum level{
LEVEL_ONE,
LEVEL_TOW,
LEVEL_THRUE,
LEVEL_FOUR,
LEVEL_FIVE,

}
//هذه قيم ثاته 
public class Student<t> {

// هذه القيم بستخدمها بداخل النود 
    private t student_name;
    private long iD;// يولد  تلقائي
    private double avarge;
    //تعريف للقسم 
    private DEPRTEMENT deprtement;//تأخذ احد هذيك القيم 
   
    private level level;//بتأخذ احد القيم الموجدة  فقط
    
    //تعريف للمستوى 
    // دوال set get
//set ترسل قيمة name =sala;
//get بتعيد قيمة rturen name;//sala;

    //كنوستركتر 
    //أكثر من صيغة للكنو ستركتر 
    
    public Student(){
 long counter=0;
 iD=System.currentTimeMillis()+(counter++); //إلإفترضي 
 deprtement=deprtement.IT;
 level=level.LEVEL_ONE;
 avarge=0.0;
}
    public Student(t student_name) {
        this();// البواب او المفتاخ هذه إستدعاء وليس بواب 
        this.student_name = student_name;
    }
// زر ايمن وبعده اسرت كود وبعدها كنوستركتر واختار الذي تريد

    public Student(t student_name,double avarge) {
     this( student_name );//إستدعاء للكنوستتركتر 
        this.avarge = avarge;
    }
    // set and get function ;

    public t getStudent_name() {
        return student_name;
    }

    public void setStudent_name(t student_name) {
        this.student_name = student_name;
    }

    public long getiD() {
        return iD;
    }


    public double getAvarge() {
        return avarge;
    }

    public void setAvarge(double avarge) {
        this.avarge = avarge;
    }

    public DEPRTEMENT getDeprtement() {
        return deprtement;
    }

    public void setDeprtement(DEPRTEMENT deprtement) {
        this.deprtement = deprtement;
    }

    public level getLevel() {
        return level;
    }

    public void setLevel(level level) {// من نوع levele
        
        this.level = level;
    }
    
// دالة كيف اطبع محتوى الاسم وليس العنوان 
    // to  strintg 

    public String toString() {
        return "[ " +"name = " + getStudent_name()
                + "\n iD = " + getiD() 
                + "\n avarge = " +getAvarge()  
                + "\n deprtement = " + getDeprtement()
                + "\n level =" + getLevel() + "]";
    }
    // هذا تشكيل الكنوستركتر 


    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Student other = (Student) obj;
        if (this.iD != other.iD) {
            return false;
        }
        if (Double.doubleToLongBits(this.avarge) != Double.doubleToLongBits(other.avarge)) {
            return false;
        }
        if (!Objects.equals(this.student_name, other.student_name)) {
            return false;
        }
        if (this.deprtement != other.deprtement) {
            return false;
        }
        return this.level == other.level;
    }
    
    

}
