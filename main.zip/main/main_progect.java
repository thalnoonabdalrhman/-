/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

//import gArray.gArraymain;
import java.util.Scanner;
import Array.Arraymain;
import stack1.main;
import list.listmain;
import queue.queue_main;
import dlist.miandlist;


/**
 *
 * @author a
 */
public class main_progect {
    public static void main(String[] args) {
       boolean found=true;
       byte op;
        do {
        System.out.println("1-  Enter th Array1-2 :");
        System.out.println("2- Enter th  LinkedList :");
        System.out.println("3-  Enter th DoubleLinkedList (set-get) :");
        System.out.println("4-  Enter th   Stack:");
        System.out.println("5-  Enter th Queue  :");
        System.out.println("6-  Enter th trees  :");
        System.out.println("7-  Enter the generci  Array(gArray) :");
        System.out.println("8-  Enter th generci  List(gList)  :");
        System.out.println("9-  Enter th generci  Double linked list (gDllist)  :");
        System.out.println("10-  Enter th generci  stack(gStack)  :");
        System.out.println("11-  Enter th generci  Queue(gQueue)  :");
        System.out.println("12-  Enter the dlinkedlist(next_prives)  ");
        System.out.println("13- Enter exit");
            switch (op=new Scanner(System.in).nextByte()) {
                case 1:
  Array.Arraymain.main(args);
                    break;
                    case 2:
  list.listmain.main(args);
                    break;
                    case 3:
   DLlist.main.main(args);

                    break;
                    case 4:
 stack1.main.main(args);
                    break;
                    case 5:
 queue.queue_main.main(args);
                    break;
                    case 6:
 tree.maintree.main(args);
 
                    break;
                    case 7:
 gArray.gArraymain.main(args);
 
                    break;
                    case 8:
 glist.listmain.main(args);
                    break;
                    case 9:
  gDLlist.main.main(args);
                    break;
                    case 10:
 gstack.main.main(args);
                    break;
                    case 11:
gqueue.queue_main.main(args);

                    break;
                    case 12:
dlist.miandlist.main(args);

                    break;
                    case 13:
                 found=false;                    
                    break;
 
                default:
                    System.out.println("retren");
            }
           
            
        } while (found);
        
        
        
                
        
        
        
        
        
//        Array.Arraymain.main(new String[]{});

    }
}
