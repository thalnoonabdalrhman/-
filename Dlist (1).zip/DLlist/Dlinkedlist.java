/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DLlist;

import com.sun.source.tree.BreakTree;

/**
 *
 * @author a
 */
public class Dlinkedlist {
    Dnode head ,tial;
//الكنوستركتر
    public Dlinkedlist(){
    head=tial=null;
    // بمسك من النهاية ومن البداية 
    }
boolean isempty(){
return (head==null)&&(tial==null);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//ملاحظة عندم اريد ان اضيف  ضروري انتقل الى جنب هذا سوى النكست او البرفيس وادخل له القيمة
//////////////////////////////////////////////////////////////////////////////////////////////////////////////



//إضافة للبداية 
public void addfirst(Dnode n){
    
    if (isempty()) {// في  حالة كانت  النود فاضية يعني هذا اول نود 
    head=tial=n;//  اول نود يمسكها الاثنينن
    return;

    }
n.setNext(head);///هنا أدخلت قيمة كأننا قلت  n.next=head ;  هنا ادخلت للمؤشر  يعني غيرت المؤشر 
head.setPrve(n);// تدخل المؤشر 
head=n; //حولت موقع الهد 

}




//إضافة للنهاية 
public void addlist(Dnode n){// DNODE N
    if (isempty()) {
        head=tial=n;
        return;
    }
   //  بشتغل من دون مأتحرك لان الموقع الاخير موجود معيا عبر الت tial
  tial.setNext(n);
  n.setPrve(n);
  tial=n;// بتساوي اخر قيمة 
}



///دالة البحث 
public Dnode fund(String sid){
    if (isempty()) {
        System.out.println(" is not found ");
      return null;
    }
Dnode team=head;//ضها بدون النكست اومعها شء طبيعي 
    while (team!=null) {//  بتعيد موقع المؤشر 
if(team.getStuden_data().getStudent_name().equalsIgnoreCase(sid)) {           
            // System.out.println(""+team);
 
          break;
        }
       team=team.getNext();
    }
return team;
}




//  دالة البحث على حسب  الموقع
public Dnode fundopstion(int opstion ){
    if (opstion==0) {
        return head;
    }
Dnode team=head;
int index=0;
//هنا بدون النكست 
//ضعها مع النكست او بدون اهم شيء تحرك الاندكس 
    while (team.getNext()!=null&&index<opstion-1) {//  بتعيد موقع المؤشر 
                 //في حالة لم يتحقق الشرط هيا النود المطلوية 
 //       System.out.println("rslt ="+team);  
     team=team.getNext();
     index++;
    }
return team;
}



// دلة إضافة بعد قيمة 
//دالة إضافة بعد قيمة 
public void addafater(Dnode n,String sid){
     // بستدعي دالة الحث 
     if (isempty()) {
        head=tial=n;
    }
     
     Dnode ruslt=fund(sid);
///في حلة كانت النود المضافة هيا اول نود 
if(ruslt==head){
    addlist(n);//إضافة الى البداية 
    
return;}
     
     /// في حالة كانت النود المدخلة هيا اخر نود 
    if (tial==ruslt) {
        addlist(n);//إضافة الى النهاية 
    return;}
    
    
    
    if (ruslt!=null) {
        n.setNext(ruslt.getNext());//n.next=ruslt.next;
        n.setPrve(ruslt);//n.prvice=ruslt;

     ruslt.getNext().setPrve(n);//ruslt.next.prve=n;
     //قيمة النود الذي واقفها عليها المؤشر حق النكست يروح الى الذي بعده الذي بعدها المدخلة حق البرفيس يساوي القيمة الجديدة 
     //وصلت الى عند القيمة من اجل تعديلها 
       ruslt.setNext(n);//rsult.next=n;
    
 return;
    }
    System.out.println("is not found ");

}



// دالة إضافة في موقع معين  موقع معين 
public  void addapostion(Dnode n,int opstion){
    if (isempty()) {
    head=tial=n;
    }
    if (opstion==0) {
        addfirst(n);// إضافة ال ى البداية 
        
        return;
    }



//دالة البحث على حسب الرقم 
Dnode ruslt=fundopstion(opstion);
//بتأكد من القيمة التي رجعت 
if (ruslt!=null) {
   //// هنا بستدعي دالة الإضافة للقيمة ورح اعطيها القيمةالتي رجعت من دالة البحث على حسب الموثع 
    addafater(n, ruslt.getStuden_data().getStudent_name());
// ruslt.getStuden_data().getStudent_name() ==تعني rslt.data النه انا معيا بيانات من ابوجكات من كلاس وهذا الكلاس ادخل لوسكه من اجل اخرج السام 
//من اجل ارجع ابحث عللى الاسم الذي رجع من دالة البحث واضيف بعده تمام 
//ا ختصرنا الدالة بكل بساطه 
}

}

///دالة اضافة بعد قيمة بحث عليها 
public void addbafore(Dnode n,String sid){
if(isempty()){
head=tial=n;
return;
}

//إستدعلء لدالة البحث 
Dnode ruslt=fund(sid);
// بترجع ليا القيم التي بحث عليها بس انا اريد القيمة الذي قبلها 
// كيف عبر النكست .prive
//بتأكد من القيمة المرجعة 
if (ruslt!=null) {
   // إستداة للدالة الإضافة 
//  برسل لها القيمة الذي قبلها 
addafater(n, ruslt.getPrve().getStuden_data().getStudent_name());
// rslt.prive ارسلت القيمة الذي قبلها 
//getStuden_data().getStudent_name() هذا بيروح للكلاس الموجدو في النود القيمة الذي موجد فيه للاسم 
//ارسلتها من نوع string وليس نود بس للنود الذي قبل الاسم الذي وجدته
// لانه وسط هذه الدالة رح يبحث عليها ثانية 
return;
}
    System.out.println("is not found ");
}

/////////////////  دالة الحذف من البداية 
public Dnode deletefirst(){
//شرط للتأكد من قيمة التي تلريد حذفها 
if(isempty())
{
 System.out.println("is empty :");
return null;
}

Dnode team=head;//من اجل اعمل ارجاع 
head=head.getNext();//head =head.next;// انا عند الهيد اذا بدخل له قية 
head.setPrve(null);//head.prvie=null //انا تحركت الى الهيد الذي بعدها الان حقها المدخل حق الربفس فاضي 
return team;
}

// حذف من النهاية 
public Dnode deletlast(){
//شرط التحقق 
if(isempty())
{
    System.out.println("is empty :");
return null;
}
//Dnode team=tial;
///// ام بنتقل اللى الخير او بحذف من خلال tial 
//// انا بوقف عند اخر نود وليس عند الذي قبلها تمام 
//// بعدها باقول النود الذي واقف عندا البرفيس حقه الان كأننا رجعت الى الذي قبلها  دت نكست يعني حق الذي قبل لاننا قد وصلت عندها تمام  تساوي فاضي 
// اول شيء ضروري هذه تمام 
//tial.getPrve().setNext(null);//tial .prive .next;// اتحركت الى عند القيمة وادخلت لها قيمة 
//tial=tial.getPrve();
//return team;

//
/////////// عن طريق البحث 
Dnode team=head;
while(team.getNext()!=null)
{
 team=team.getNext();

}
Dnode cornet=team;
team.getPrve().setNext(null);//team.prve.next=null;// هذه ضرور ي ارجعت النكست حق النودالذي قبلها بفاضي لان اصل النكست دائما فاضي في الخير تمام 
// ضرور ي اشتغل هذه الخطوة قبل لانه اذا قدمت البرفيس وعملتها بعدها برجع بعده ارجع النكست بنل برجع الى النود الذي قبل قبل النود 
// برجع من النود الذي رجعت لها البرفيس  ولان ارجع  ارجع من الذي قبلها لانها قد احتذفت تمام 

team=team.getPrve();// team=team.prve نقل البرفيس خطوة للامامةلان يكون مربوط بقيمة لا تستطيع وضعه بفاضي تمام 

return cornet;

}




// دالة الحذف على حسب القيمة 
public void deletf(String s){
    if (isempty()) {
        System.out.println("is empty :");    
    return;    }
    // في حالة لسيت اخر نود نود ولا اول نود 
//  دالة البحث عن القيمة 
Dnode rslut=fund(s);
    System.out.println("rslt "+rslut);
    // في حالة النود المراد حذفها هيا اول نود 
    if (head==rslut) {
        deletefirst();
        return;
    }
// في حالة كانت اخر نود 
if (tial==rslut) {
    System.out.println("tial "+tial);
  deletlast();
  return;
 
}

// هنا الحذف 
rslut.getPrve().setNext(rslut.getNext());//بوقف عند النود المراد حذفها بعدها البرفيس حقها يؤشر على الذي قبلها النكست الذي قبلها 
//مصلت الى المطلوب النكست غير قيمة الى النكست الذي بعد النكست المراد حذفها 

rslut.getNext().setPrve(rslut.getPrve());
// هنا انا واقف عند النود المراد حفها بعد بنتقل الى الذي بعدها عبر النكست 
//  الان وقفت عند النود الذي بعد بعددها بغير قيمة البرفيس حق هذا النود واجعلة محل البرفيس حق النود المحذوفة 

// شرحها في الدفتر مبسط 
rslut.setPrve(null);//تأكيد الفصل للقيمة 
}






//دالة الحذ على حسب الموقع 
public Dnode deletopstion(int opstion) {
    if (isempty()) {
        System.out.println("is empty :");   
    return null;
    }
    
    // اول موقع    
    if (opstion==0) {
       // deletefirst();
//دالة الحذ من البداية س
return deletefirst();
    }
// في حالة اخر موفع 
if (opstion==getsize()) {
    return deletlast();// حذف اخر قيمة 
    }
// بستدعي دالة البحث من اجل ترجع ليا القيمة حسب الموقع 
Dnode ruslt=fundopstion(opstion);
// الان بستدعي دالة الحذف 
deletf(ruslt.getStuden_data().getStudent_name());

return ruslt;
}


// حذف النود الذي قبل 
public void deletbafore(String s){
    if (isempty()) {
        System.out.println("is empty :");    
    return;
    }
// دالة البحث 
Dnode rslt=fund(s);
//  القيمة التي رجعت برسلها الى دالة الحذف بس بعمل القيمة الذي قبل وليس نفس القيمة الراجعة من البحث كيف 
// عن طريق prive  برجع خطوة للأمام 
// برسل من هذه البانات التي رجعت خطوة للبرفيس النص حق الاسم لاننا ببحث عنه ثانية في دالة الحذف 
deletf(rslt.getPrve().getStuden_data().getStudent_name());// من النود المزن في الكلاس المخزن فية نص الاسم هكذا تعني 
//rslt.prvie
//عبر getprive() //,prive

}


// حذف النود الذي قبل 
public void deletafter(String s){
    if (isempty()) {
        System.out.println("is empty :");    
    return;
    }
// دالة البحث 
Dnode rslt=fund(s);
//  القيمة التي رجعت برسلها الى دالة الحذف بس بعمل القيمة الذي قبل وليس نفس القيمة الراجعة من البحث كيف 
// عن طريق prive  برجع خطوة للأمام 
//عبر getnext() //,next
// برسل من هذه البانات التي رجعت خطوة للبرفيس النص حق الاسم لاننا ببحث عنه ثانية في دالة الحذف 
deletf(rslt.getNext().getStuden_data().getStudent_name());// من النود المزن في الكلاس المخزن فية نص الاسم هكذا تعني 
//rslt.prvie
}




//دالة حجم النود 
public int getsize(){
 Dnode team=head;
 int count=0;
    while(team!=null){
      team=team.getNext();
   count++;
    } 
    return count;
}



public void display(){
    Dnode team=head;
    System.out.println("");
    while(team!=null){
       System.out.print(""+team);
      team=team.getNext();
        System.out.println("\n");
   } 
}

}


