
package DLlist;

import java.util.Scanner;

public class main {
    public static void main(String[] args) {
       boolean found=true;
        Dlinkedlist d=new Dlinkedlist();

       do {            
        System.out.println("1-  Enter th addfirst :");
        System.out.println("2- Enter th addlist :");
        System.out.println("3-  Enter th addafter  :");
        System.out.println("4-  Enter th addbefore  :");
        System.out.println("5-  Enter th add_opstion  :");
        System.out.println("6-  Enter th deletfirst  :");
        System.out.println("7-  Enter the deletlast ");
        System.out.println("8-  Enter th deletvalue  :");
        System.out.println("9-  Enter th deletafter  :");
        System.out.println("10-  Enter th deletbafore  :");
        System.out.println("11-  Enter th deletopstion  :");
        System.out.println("12-  display  ");
        System.out.println("13-  getsize  :");
        System.out.println("14- Enter exit");
        
        byte op;
            switch (op=new Scanner(System.in).nextByte()) {
                case 1:
           Student s=new Student("mhmaed" );
           s.setStudent_name("manhad ");
     System.out.println("enter the depertment :");
s.setDeprtement(DEPRTEMENT.valueOf("SE"));
           d.addfirst(new Dnode(s));
            Student o=new Student("tial ");
            s.setDeprtement(DEPRTEMENT.valueOf("RE"));

           d.addfirst(new Dnode(o));  
                    break;
                   case 2:
       Student p=new Student("acala");
        d.addlist(new Dnode(p));

                    break;
                    case 3:
      Student f=new Student("thalnoon");
       Student t=new Student("abdalurhmain");

   d.addafater( new Dnode(f),"mhmaed");
  d.addafater(new Dnode(t),"thalnoon");              
                    break;
                case 4:
        d.addbafore(new Dnode(new Student("sipr")),"thalnoon");
        Student m=new Student("all");
        d.addbafore(new Dnode(m),"thalnoon");
                   
                    break;
                 case 5:
       Student u=new Student("salh");
      d.addapostion(new Dnode(u), 2);             
                    break;
                    case 6:
          System.out.println("deletfirst ="+d.deletefirst());
                    break;
                    case 7:
        System.out.println("deletfirst ="+d.deletlast());
          
                    break;
                    case 8:
                        //حذف قيمة 
          d.deletf("acala");
                   
                    break;
                    case 9:
                        //حذف بعد قيمة 
         d.deletafter("all");
           
                    break;
                    case 10:
                        //حذف قبل قيمة 
        d.deletbafore("acala");
            
                    break;
                    case 11:
          d.deletopstion(5);

                    break;
                    case 12:
           d.display();
            
                    break;
                    case 13:
     System.out.println("    getsize"+    d.getsize());
               
                    break;
                    case 14:
            found=false;        
                    break;
                default:
                    System.out.println("Retry :");            }
        } while(found);

        
        
        
 
       
       
       
       
       
       
       

////        Student s=new Student("mhmaed" );
////       
////                 d.addfirst(new Dnode(s));
//  //     System.out.println("dnode ="+s.toString());
//////
////        Student o=new Student("Ahmad ");
////
////   // s.setStudent_name("k");
////      d.addfirst(new Dnode(o));
//      
////       System.out.println("dnode ="+s.toString());
////       Student p=new Student("acala");
//
//  // s.setStudent_name("kk");
//        //System.out.println(s.toString());
////    
////       System.out.println("dnode ="+s.toString());
//////       
////         Student f=new Student("thalnoon");
////         Student t=new Student("abdalurhmain");
////
////   d.addafater( new Dnode(f),"ahmad ");
////  d.addafater(new Dnode(t),"mhmaed");
////    d.addlist(new Dnode(p));
////   Student u=new Student("salh");
////
////   d.addapostion(new Dnode(u), 2);
////     Student m=new Student("all");
////     d.addbafore(new Dnode(m), "thalnoon");
//       
//     
//  // System.out.println("     d.deletefirst()       " +     d.deletefirst());
////      d.addbafore(new Dnode(p),"thalnoon");
//System.out.println("    getsize"+    d.getsize());
////d.deletf("all");
//  //d.deletopstion(5);
//  //System.out.println("deletlist ="+d.deletlast());
////d.deletf("Ahmad");
////d.deletbafore("acala");
//d.deletafter("all");
//
//        d.display();
    }
   
}