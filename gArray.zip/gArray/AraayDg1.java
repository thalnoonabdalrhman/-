



package gArray;

import java.util.Scanner;
import Array.AraayD1;
public class AraayDg1<T> {

    T[] data;
public    int cruntpostion;
int count3;


 public   AraayDg1 (int sizes) {
        data = (T[])new Object[sizes];
     cruntpostion=-1;
    }
    
   public AraayDg1() {
       
        this.data = (T[])new Object[10];
        cruntpostion=-1;
//عملت كسنج لتحويلها من نوع مصفوفة 
//ال نوع جينرك 
    }
   boolean isempty(){
   return cruntpostion==-1;
   }
   boolean isfull(){
   return cruntpostion==data.length-1;
   }
    
// دالة إدخال 
    public void insert(T iteam) {
        if (isfull()) {
            System.out.println("is full"); 
        return;
        }
        data[++cruntpostion]=iteam;
        System.out.println("counte"+cruntpostion); 
    count3=cruntpostion;
    }
// دالة الطباعة 
public void display() {
        if (isempty()) {
            System.out.println("isempty ");
        return;
        }
        System.out.println("araay elemen the are  :");
        for (int i = 0; i < cruntpostion; i++) {
            System.out.println(data[i] + "\t");
        }

        
    }
  // دالة الحذف بدون تكرار1  
    
   //تحذف اول قيمة من اول المصفوفة وجدها حتى لو وجد تكرارت مارح يحذف التكرارت
T[] deletiteam(T iteam){
// ابحث عن العنصر 
// اضع قيمة العنصر  يصفر 
//يخول العنصر  الى اخر شيء في المصفوفة 
int index=-1;
boolean found=false;
   if (isempty()) {
            System.out.println("isempty ");
        return null;
        }
for (int i = 0; i <cruntpostion; i++) {
    if (data[i].equals(iteam)) {
    index=i;
    found=true;
    data[i]=null;// لانها رجعت من نوع جينرك 
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
        break;
        
    }
    
    }
    if (found) {
        // ناقص  واحد لانه اذاوقف عند العنصر الاخير ويريد الذي الذي بعده يطلع غلط 
        for (int i = index; i <cruntpostion-1; i++) {
         data[i]=data[i+1];
        }
            cruntpostion--;// بنقص حجم المصفوفة 
        data[cruntpostion-1]=null;
    }else{
        System.out.println("element is not found :");
    }
return data;
}

   
//في حالة اريد ان احذف مع التكرار 
// اخلي اول قيمة واحذف التكرارت
// الحذف مع التكرار بشرط ان نترك العنصر الاول من التكرار 

void deletiteam3(T iteam){
// ابحث عن العنصر 
// اضع قيمة العنصر  يصفر 
//يخول العنصر  الى اخر شيء في المصفوفة 

if (isempty()) {
            System.out.println("isempty ");
        return;
        }
int index=-1;
int c=0;
boolean found=false;
int sizse=data.length;   
for (int i = 0; i <cruntpostion; i++) {
    if (data[i].equals(iteam)) {
        if(c>=1){
    index=i;
    found=true;
    data[i]=null;
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
    //في هذه الحالى يحذف جميع البيانات التي تكررت ويضع بدلها صفر لكن الترتيب ليس تمام 
   for (int j = index; j <cruntpostion-1; j++) {
          
      data[j]=data[j+1];
      }
    data[cruntpostion-1]=null;
    // من اجل التأكد من القيمة الذي حولنها هل هيا نفسها 
      --i;
 //  i--;
  // sizse--;
  //هذه صحيحة مئة بالمئة متبقي كيف احذ ف القيم الاخيرة كامل 
    cruntpostion--;
    }
    c++;
    }
    }
    if (found) {
        // ناقص  واحد لانه اذاوقف عند العنصر الاخير ويريد الذي الذي بعده يطلع غلط 
       
    }else{
        System.out.println("element is not found :");
    }


}


// اريد مثلا اخر قيمة واحذف الذي قبهلا مكرر كامل 
//الحذف مع التكرار بشرط ان نترك اخر عنصر من التكرار 
void deletiteam4(T iteam){
if (isempty()) {
       System.out.println("isempty ");
        return;
        }

// ابحث عن العنصر 
// اضع قيمة العنصر  يصفر 
//يخول العنصر  الى اخر شيء في المصفوفة 
int index=-1;
int c=0;
boolean found=false;
int sizse=data.length;   
for (int i = cruntpostion-1; i >=0; i--) {
    if (data[i].equals(iteam)) {
        if(c>=1){
    index=i;
    found=true;
    data[i]=null;
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
    //في هذه الحالى يحذف جميع البيانات التي تكررت ويضع بدلها صفر لكن الترتيب ليس تمام 
   for (int j = index; j >0; j--) {
          
      data[j]=data[j-1];
      
       System.out.print("  ==="+data[j]+"\t");   
   }
    data[0]=null;
     --i;
     cruntpostion--;
  // sizse--;
  //هذه صحيحة مئة بالمئة متبقي كيف احذ ف القيم الاخيرة كامل 
    }
    ++c;
    }
    }
    if (found) {
        // ناقص  واحد لانه اذاوقف عند العنصر الاخير ويريد الذي الذي بعده يطلع غلط 
        
    }else{
        System.out.println("element is not found :");
    }


}
/// الحذف مع التكرار بشرط ترك ثاني قيمة من التكرارت
void deletiteam5(T iteam){
// ابحث عن العنصر 
// اضع قيمة العنصر  يصفر 
//يخول العنصر  الى اخر شيء في المصفوفة 
if (isempty()) {
            System.out.println("isempty ");
        return;
        }

int index=-1;

int c=1;
boolean found=false;
int sizse=data.length;   
for (int i = 0; i<cruntpostion; i++) {
    if (data[i]==(iteam)) {
        //  عددد التكرارات في حالة وجد اول مرة التكرار يكون بواحد بيدخل ويحذف في المرة الثانية 
  //بيزيد على التكرار بيكون اثنين بيقول هل الاثنين لا يساوي الاثنين  خطى مارح يدخل الحلقة المرة الثالثة بيزيد على قيمة التكار بيكون ثلاثة
        //الان بيجي يقارن وهيا هل الثلاثة لا تساوي الاثنين بيكون نعم بيدخل ويحذف وهكذا بعده يعني تعدي القيمة 
        if(c!=2){
    index=i;
    found=true;
    data[i]=null;
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
    //في هذه الحالى يحذف جميع البيانات التي تكررت ويضع بدلها صفر لكن الترتيب ليس تمام 
   for (int j = index; j <cruntpostion-1; j++) {
          
      data[j]=data[j+1];
      
       System.out.print("  ==="+data[j]+"\t");   
   }
    data[cruntpostion-1]=null;
    // من اجل يرحع خطوة للأمام من اجل التأكد 
    --i;
  // sizse--;
  //هذه صحيحة مئة بالمئة متبقي كيف احذ ف القيم الاخيرة كامل 
    cruntpostion--;
        }
    ++c;
    }
    }
    if (found) {
        // ناقص  واحد لانه اذاوقف عند العنصر الاخير ويريد الذي الذي بعده يطلع غلط 
        
    }else{
        System.out.println("element is not found :");
    }

}
// مصفوفة احادية تحذف مع التكرار ماعدى لبقيمة الاخير 
// والتحويل الى نهاية  المصفوفة 

public T[] deletiteam_one_array(T iteam){
// ابحث عن العنصر 
// اضع قيمة العنصر  يصفر 
//يخول العنصر  الى اخر شيء في المصفوفة 
int index=-1;
int c=0;
boolean found=false;
int sizse=data.length;   
for (int i = data.length-1; i >=0; i--) {
    if (data[i]. equals(iteam)) {
        System.out.println("data delete "+data[i]);
        if(c>=1){
    index=i;
    found=true;
    data[i]=null;
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
    //في هذه الحالى يحذف جميع البيانات التي تكررت ويضع بدلها صفر لكن الترتيب ليس تمام 
   for (int j = index; j <data.length-1; j++) {
          
      data[j]=data[j+1];
      
     //  System.out.print("  ==="+data[j]+"\t");   
   }
    data[data.length-1]=null;
    --i;
  //هذه صحيحة مئة بالمئة متبقي كيف احذ ف القيم الاخيرة كامل 
    }
    ++c;
    }
    }
    if (found){
        // ناقص  واحد لانه اذاوقف عند العنصر الاخير ويريد الذي الذي بعده يطلع غلط 
       System.out.println("data ;");
    }else{
        System.out.println("element is not found :");
    }

return data;
}

// دالة التحويل من تنائية الى احادية 
public  T[] converting2(int dataarray2[][]){
T array1iteam[]=(T[])new Object[dataarray2.length*dataarray2[dataarray2.length-1].length];
// حجم الصف في حجم العمود
int count=0;
    for (int i = 0; i < dataarray2.length; i++) {
      for (int j = 0; j < dataarray2[i].length; j++) {
      array1iteam[count]=(T)(Integer)dataarray2[i][j];
         ++count; 
     }
    }
  data=array1iteam;
    for (int i = 0; i < array1iteam.length; i++) {
       insert(array1iteam[i]);
        System.out.println("arraydata ="+data[i]);
    }
  data=array1iteam;
    return data;
}

//في حالة اريد ان احذف مع التكرار 
// دالة الحذف مع التكرار2
public T[] deletiteam1(T iteam){
// ابحث عن العنصر 
// اضع قيمة العنصر  يصفر 
//يخول العنصر  الى اخر شيء في المصفوفة 


if (isempty()) {
            System.out.println("isempty ");
        return null;
        }
int index=-1;
int c=0;
boolean found=false;
int sizse=data.length;   
for (int i = 0; i <cruntpostion; i++) {
    if (data[i]==(iteam)) {
    index=i;
    found=true;
    data[i]=null;
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
    //في هذه الحالى يحذف جميع البيانات التي تكررت ويضع بدلها صفر لكن الترتيب ليس تمام 
   for (int j = index; j <cruntpostion-1; j++) {
          
      data[j]=data[j+1];
      }
    data[cruntpostion-1]=null;

   --i;
 //  i--;
  // sizse--;
  //هذه صحيحة مئة بالمئة متبقي كيف احذ ف القيم الاخيرة كامل 
    cruntpostion--;
    }
    }
    if (found) {
        // ناقص  واحد لانه اذاوقف عند العنصر الاخير ويريد الذي الذي بعده يطلع غلط 
                display();

    }else{
        System.out.println("element is not found :");
    }

return data;
}

///////////////////////////////
//
// التحول  من اثنائية الى احادية من نوع جينرك 
public void conversion(T data2d[][]){
    T team_array[]=(T[])new Object[(data2d.length*data2d[data2d.length-1].length)]; 
    int count=0;
    System.out.println("data"+data2d.length);
    for (int i = 0; i < data2d.length; i++) {
        for (int j = 0; j < data2d[i].length; j++) {
   team_array[count++]=data2d[i][j];
        }
   
    
    }
//  عمل مصفوفة بحجم العناصر الذيي سوف تخزنها في المصفوفة الاصل العناصر المدخلة  
   data=team_array;
    //  اعطاء الحجم للمصفوفة الاصل الذي بشتغل عليها 
for (int j = 0; j <team_array.length; j++) {
         //عملية النسخ 
//         data[j]=inteam_array[j]);
         // بعمل لها مباشرة ادخال  للثسم مباشرة  
         insert(team_array[j]);
         
        }
//  معا تحتاج ارجاع القيمة لانك خزنتها مباشرة 
}
  }
