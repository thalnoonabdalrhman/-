/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gArray;

import java.text.Normalizer;
import java.util.Scanner;
import Array.ArrayD2;
import gArray.AraayDg1;
/**
 *
 * @author a
 */
public class AraayDg2<t> {
   
     t[][] data;
    int countrow,countcol;
    //كنوستركتر من نفس نوع الكلاس 
public AraayDg2(){
this.data=(t[][])new Object[3][6]; // هنا عملية كستنج من اجل ان يحول المصفوفة من granc 
countrow=countcol=-1;//هذه من اجل احدد الصفوف والعمود عندما اضيف 
}
   public AraayDg2(int row1, int col1) {
        this.data = (t[][])new Object[row1][col1];
// انشى ليا ابوجكت في حالت ابعدت الابوجكت بليغي فكرة الجيرنك 
  countrow=countcol=-1;
   
   //يعني المصفوفة ولا يوجد فيها شيء وسوف اتعامل معها من خلال العمود والصف 
   }
   boolean isfull(){
    System.out.println("co  "+countcol);
    return (countcol==data[data.length-1].length) &&(countrow==data.length);// اخر صف من المصفوفة هل قيمة العمود عنده يعني انا في الاخير 
         //في كانت في اخر موق في وكذالك في العمود 

   ///هنا شرط التحقق من ان المصفوفةممتلئة 
   // في حالة العمود يساوي اخر  قيمة للعمود في اخر صف 
   // كذالك في حالة الصف هو اخر صف 
         
  
         
   }

boolean isempty(){
return countrow==-1&&countcol==-1;
}

 public void insert(t iteam) {

        if (isfull()) {
            System.out.println("is full");
           return;
        }
        // هذا الشرط من اجل اول مرة بدخل اعمل اضافة بيشوف اذا هيا فاضي بيحول قيمة الصق والعمود الى صفر 
         if (isempty()) {// في حالةكانت فارغ يعني انا باضيف اليها 
          countcol++;//من اجل تفادي غلط اول مره 
          countrow++;
         }
                        
            
           // }
           // هذا الشرط يتاكد من اننا لم اصل الى اخر المصفوةفة 
            if (countrow!=data.length) {// في حالة لم اتعدي حجم المصفوفغة 
           //
//                System.out.println("cornt "+countcol);
//                System.out.println("row "+countrow);
                data[countrow][countcol++]=iteam;// بزود على قيمة العمود كل مرة الان انا قد زوت قيمته فوق لو عملت الزيادة قبل بيخلي الموقع
               // الاول فاضي 
               // يضيف الى الصف  مع تحريك العمود عند كل اضافة 

                    }
            // شرط في حالة كان عند اخر قيمة  في العمود من اجل انتقل الى الصف الذي بعده وارجع العمود بصفر 
            if (data[countrow].length==countcol) {//اذاكان الصف الذي انا واقف فيه يساوي يساوس قيمة العمود الذي مشي للعنده 
             countcol=0;
             countrow++;
               // System.out.println("counf t"+countrow);
         }//else{
            

//                     for (int i = 0; i <=countrow; i++) {
//                    for (int j = 0; j <=countcol; j++) {
//                System.out.println("iteam "+data[i][j]);
//                }
// System.out.println("iteam "+data[0][0]);
// System.out.println("iteam "+data[0][1]);
//           System.out.println("iteam "+data[1][0]);
//                 System.out.println("iteam "+data[1][1]);

            //}
            }
           
            
        

    

 
 public    void display() {
        System.out.println("araay elemen the are  :");
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {

                System.out.print(data[i][j] + "\t");
            }
            System.out.println("");
        }
  
  }
 // 1 حذف بدون تكرار 
   //تحذف اول قيمة من اول المصفوفة وجدها حتى لو وجد تكرارت مارح يحذف التكرارت
public void deletiteam(t iteam){
// ابحث عن العنصر 
// اضع قيمة العنصر  يصفر 
//يخول العنصر  الى اخر شيء في المصفوفة 
int indexrow=-1;
int indexcol=-1;

boolean found=false;
        
    
for (int i = 0; i <data.length; i++) {
        for (int j = 0; j <data[i].length; j++) {

    if (data[i][j].equals(iteam)) {
    indexrow=i;
    indexcol=j;
    found=true;
    data[i][j]=null;
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
        break;
        
    }}
    
    }
    if (found) {
        // ناقص  واحد لانه اذاوقف عند العنصر الاخير ويريد الذي الذي بعده يطلع غلط 
        
        for (int i = indexcol; i <data[indexrow].length-1; i++) {
                
            
            data[indexrow][i]=data[indexrow][i+1];
        }
       // System.out.println("daa"+data[indexrow].length);
        //System.out.println(""+indexrow);
         data[indexrow][data[indexrow].length-1]=null;
         System.out.println("suecess full;");
    }else{
        System.out.println("element is not found :");
    }
}

//2 الحذف مع التكرار
public void deletiteam3(t iteam){
// ابحث عن العنصر 
// اضع قيمة العنصر  يصفر 
//يخول العنصر  الى اخر شيء في المصفوفة 
int indexrow=-1;
int indexcol=-1;

boolean found=false;
        
    
for (int i = 0; i <data.length; i++) {
        for (int j = 0; j < data[i].length; j++) {

    if (iteam.equals(data[i][j])) {
    indexrow=i;
    indexcol=j;
    found=true;
    data[i][j]=null;
   //حولت قيمة الموقع الى صفر 
 for (int i1 = indexcol; i1 <data[indexrow].length-1; i1++) {
                
           
            data[indexrow][i1]=data[indexrow][i1+1];
        }
 int o=0;
        data[indexrow][data[indexrow].length-1]=null;  
    --j;
    //برجع اتأكد هل القيمة مازالت موجودة 
    }
      }
    
    }
    if (found) {
        System.out.println("تم التعديل والحذف للعنصر "); 
       
    }else{
        System.out.println("element is not found :");
    }
}




//في حالة اريد ان اعمل إزاحة للعنصر الذي حولت قيمتة بصفر الى أخرى المصفوفة 

// بإستخدام المصفوفة الثانية 
public void deletiteam4(t iteam,t zero){
int c1=0;
  int c2=0;
    boolean found=false;
    System.out.println("");
    System.out.println("");
for (int i = 0; i <data.length; i++) {
        for (int j = 0; j < data[i].length; j++) {

    if (data[i][j].equals(iteam)) {
        System.out.println("is deletion ");
    c1=i;//هناوضعت  موقع الصف الذي يوجد فيه العنصر  
    c2=j;//هنا وضعت  موقع العمود الذي العنصر موجود فيه 
    
    found=true;
    for (int i1 = c1; i1 <data.length ; i1++) {//هناببداء من الصف الذي وفقت فيه الى حجم المصفوفة بالكامل 
          for (int j1 = c2; j1 < data[i].length-1; j1++) {  // عدد الأعمدة في الصف الذي انا وافق فيه
       data[i1][j1]=data[i1][j1+1];//هنا عملية تحويل للصف الاول بالكامل  يعني بيمشي في العمود الاول والثاني حتي يصل الى الاخير وهكذا 
        System.out.print("h = "+data[i1][j1]+" ");
   
          }
          c2=0;//عندما يخرج برجع قيمة العمود بصفر لان العمود في الصف الثاني بيبداء من صفر 
          c1=i1+1;// هنا بزود على قيمة الصف من اجل انتقل الى الصف الثاني 
      if(c1<=data.length-1){//لم يكون السي اصغر بيدخل ينفذ اخر مرة مار يدخل ينفذ لانه بيطلع اكبر من الحجم المطلوب 
          //هنا بتأكد من اجل اخر عملية لا تدخل هنا بتأكد هل الصف اقل او يساوي اخر موقع في المصفوفة ناقص واحد 
          // يعني الذي قبل الأخير 
          //من اجل اذا زادت قيمة الصف على المصفوفة ما يدخل ويطلع غلط 
  data[i1][data[i1].length-1]=data[c1][c2];//هنا تعني اخر عنصر في الضف الاول من العمود الاخير بيساوي اول عنصر من الصف الثاني العمود الأول 
      }
        }
data[data.length-1][data[data.length-1].length-1]=zero;
// هنا تعني اخر عنصر من المصفوفة في الصف الاخير 
//في اخر عمود من هذا الصف 
//[data[data.length-1].length-1]تعني اخر عمود من الصف الاخير 

         System.out.println("");
        
j--;// من اجل الأكد هل احتذف العنصر ام لا 
    }
        }}
}    

// الحذف مع التكرار بشرط ترك العنصر الاول من التكرارت 


public void deletiteam5(t iteam,t zroe){
// ابحث عن العنصر 
// اضع قيمة العنصر  يصفر 
//يخول العنصر  الى اخر شيء في المصفوفة 
int indexrow=-1;
int indexcol=-1;

boolean found=false;
int c=0;        
 
for (int i = 0; i <data.length; i++) {
        for (int j = 0; j < data[i].length; j++) {

    if (data[i][j].equals(iteam)) {
       if(c>=1){// التأكد هل هو اول تكرار ام اخرى تكرار 
    indexrow=i;
    indexcol=j;
    found=true;
    data[i][j]=zroe;
   //حولت قيمة الموقع الى صفر 
 for (int i1 = indexcol; i1 <data[indexrow].length-1; i1++) {
                
            
            data[indexrow][i1]=data[indexrow][i1+1];
        }
        data[indexrow][data[indexcol].length-1]=zroe;  
    --j;
    //برجع اتأكد هل القيمة مازالت موجودة 
    }
   c++;
    }
      }
    
    }
    if (found) {
        System.out.println("تم التعديل والحذف للعنصر "); 
       
    }else{
        System.out.println("element is not found :");
    }
}
///  تحويل العنصر الى الخير بإستخدام ثلاث دوال 
// الحذف مع تحريك العنصر الذي تم حذفه الاى الخير بإستخدام المصفوفة الثنائية 
//حولها الى مصفوفة احادية واحذف ثم رجعها الى مصفوفة ثنائية 
public void deletiteam6(t iteam){
    // ضروري ارجع المصفوفة من نوع جينرك 
    //  اعمل لها ايضا كستنج من اجل ترجع من نوع جينرك لانه ماتقدر تنشء مصفوفة من جينرك مباشرة 
t teamarray[]=(t[])new Object[data.length*data[data.length-1].length];// قيمة الصف في اخر قيمة للعمود 
// ليش ناقص واحد لانه بيزيد على حجم المصفوفة بيكون مش موجود العمود 
//  لانه هنا بيقول العمود الثالث  عند اخر صف في المصفوفة لان المصفوفة حجمها بيبداء من واحد 
//ولو وقفت عند اخر حجم يعتبر مش موجود لانها تبداء من صفر 
    System.out.println(" sizs ="+data.length*data[data.length-1].length);

    int count=0;
    for (int i = 0; i < data.length; i++) {
      for (int j = 0; j < data[i].length; j++) {
      teamarray[count]=data[i][j];
         ++count; 
     }
    }

    
    
//حذف مع التكرار 
int index=-1;
boolean found=false;
for (int i = 0; i <teamarray.length; i++) {
   if (teamarray[i].equals(iteam) ){
    index=i;
    found=true;
    teamarray[i]=null;//  ضروري القيمة ترجع بنل لان المصفوفة من جينرك
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
    //في هذه الحالى يحذف جميع البيانات التي تكررت ويضع بدلها صفر لكن الترتيب ليس تمام 
   for (int j = index; j <teamarray.length-1; j++) {
          
      teamarray[j]=teamarray[j+1];
      }
    teamarray[teamarray.length-1]=null;

   --i;//التأكد من العناصر هل موجودة اكثر من  مرة 
   
 //  i--;
  // sizse--;
  //هذه صحيحة مئة بالمئة متبقي كيف احذ ف القيم الاخيرة كامل 
        }
    }
int count1=0;
    if (found) {
        System.out.println("teamarray");
        for (int i = 0; i < count; i++) {
            System.out.print(" "+teamarray[i]);
        }
        for (int i = 0; i < data.length; i++) {
      for (int j = 0; j < data[i].length; j++) {
      data[i][j]=teamarray[count1];
          ++count1;
     }
    }
    }else{
        System.out.println("element is not found :");
    }


}



// دالة التحويل الى مصفوفة احادية 
public t[] data (){
//  مصفوفة لحادية بخجم المصفوفة الثنائية 
//ضروري تحول المصفوفة من نوع جينرك لان المصفوفة الثنائية من نوع جينرك وكيف بتخلي الاحادية تاخذ القيم وليس من نوع جينرك 

t array1iteam[]=(t[])new Object[data.length*data[data.length-1].length];
// حجم الصف في حجم العمود
int count=0;
    for (int i = 0; i < data.length; i++) {
      for (int j = 0; j < data[i].length; j++) {
      array1iteam[count]=(t)data[i][j];
         ++count; 
     }
    }
    
     for (int i = 0; i < count; i++) {
  System.out.println(" Araay one da : "+array1iteam[i]);  
//  
}
//    System.out.println("is conversion is successfuly :");
return array1iteam;//بترجع قيم من نوع مصفوفة من اجل اتعامل مع المصفوفة 
// بترجع قيم من نوع مصفوفة من جينرك 
}


// دالة حذف العناصر في المصفوة الاحادية  
//  مع التحويل الى البداية 

public t[] deletAraay1(t []data,t iteam){
// بترجع بيانات من نوع مصفوفة من نوع جينرك 
boolean found=false;
for (int i = 0; i <data.length; i++) {
   if (data[i]==(iteam)) {
    int index=i;
    found=true;
   
    data[i]=null;
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
    //في هذه الحالى يحذف جميع البيانات التي تكررت ويضع بدلها صفر لكن الترتيب ليس تمام 
   for (int j = index; j <data.length-1; j++) {
          
      data[j]=data[j+1];
      }
    data[data.length-1]=null;

   --i;//التأكد من العناصر هل موجودة اكثر من  مرة 
   
 //  i--;
  // sizse--;
  //هذه صحيحة مئة بالمئة متبقي كيف احذ ف القيم الاخيرة كامل 
    }
    }
    if (found) {
//            for (int i = 0; i < data.length; i++) {
//        System.out.println(" data :"+data[i]);   
//    }
//        System.out.println("iteama is delet ");
//        
    }else{
        System.out.println("element is not found :");
    }

// بيعيد ليا المصفوفة التي حذفها 
return data;

}
// من احادية الىمصفوفة ثانية  من نوع مصفوفة ثنائية 
 

// دالة تعيد القيم الى مصفوفة ثنائية 
// تستقبل قيم من نوع جينرك لمصفوفة 
// من احادية الى ثنائية جينرك 
public void conversionToAraay2(t[] deletAraay1){
    System.out.println(" المصفوفة في وضع التحول ");
      int count=0;  
        for (int i = 0; i < data.length; i++) {
      for (int j = 0; j < data[i].length; j++) {
      data[i][j]=deletAraay1[count];
          ++count;
     }
    }


}
// دالة الحذف الى الإخير بإستخدام الثلاث الدوال 
public void deletiteam7(t iteam){
t array1conversion[]= data();// استدعاء دلة التحويل //  دالة التحويل من ثنائي الى احاد
//طباعة للتأكد من انه تم النحويل 
//for(int i=0;i<=array1conversion.length-1;i++){
//    System.out.println("ARRAY 1 "+array1conversion[i]);
//    
//     
//}
    // استدعاء لدالة الحذف
    ///  بترجع من نوع  جينرك 
 t array1[]=deletAraay1(array1conversion,iteam);//دالة  الحذ الاحادية 
  // استدعا لدلة تحويل ال/مصفوفة الى ثنائية 
  conversionToAraay2(array1);//  دالة التخول من احادي الى ثنائي 
}
// تعمل ليا صفر 

///جمع دالتي

//public int sumAarray2(t[][] t){
//        
//        }
//        




// مصفوفة احادية تحذف مع التكرار ماعدى القينة المكررة اذا كانت اخر قيمة   
// والتحويل الى نهاية  المصفوفة 

public t  delet_list(t[] data,t iteam){
// ابحث عن العنصر 
// اضع قيمة العنصر  صفر 
//يخول العنصر  الى اخر شيء في المصفوفة 
int index=-1;
int c=0;
boolean found=false;
int sizse=data.length;   
for (int i = data.length-1; i >=0; i--) {
    if (data[i]==(iteam)) {
        if(c>=1){
    index=i;
    found=true;
    data[i]=null;
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
    //في هذه الحالى يحذف جميع البيانات التي تكررت ويضع بدلها صفر لكن الترتيب ليس تمام 
   for (int j = index; j <data.length-1; j++) {
          
      data[j]=data[j+1];
      
      // System.out.print("  ==="+data[j]+"\t");   
   }
    data[data.length-1]=null;
    --i;
  //هذه صحيحة مئة بالمئة متبقي كيف احذ ف القيم الاخيرة كامل 
    }
    ++c;
    }
    }
    if (found) {
        // ناقص  واحد لانه اذاوقف عند العنصر الاخير ويريد الذي الذي بعده يطلع غلط 
        
    }else{
        System.out.println("element is not found :");
    }

return (t)data;
}

//  دالة الحذف 
//باستخدام التحول من مصفوفة ثنائية الى احادية 
// حذف العناصر في المصفوفة الاحادية  مع التكرار 
//   التحول من احادية الى ثنائية 
public void delete_list(t iteam){
t arayteam[]=data();

//t arraydelete=delet_list(arayteam,iteam,zero);

conversionToAraay2((t[]) delet_list(arayteam,iteam));// دالة التحويل 

}

// كلها arraylist
// حذف العناصر في المصفوفة الثنائية ما عد  القيمة الاخيرة بإستخدام ثلاث دوال 
//باستخدام التحول من مصفوفة ثنائية الى احادية 
// حذف العناصر في المصفوفة الاحادية  ماعد الاخيرة المكررة   التكرار 
//   التحول من احادية الى ثنائية

AraayDg1 arrayone=new AraayDg1();

public void conf(t [][]array){
//  التحول من ثناية الى احادية 
arrayone.conversion(data);
}

//  دالة الحذف للقيم   الاحادية 
public t[] deletone_array(){

///
System.out.println("Enter the delete iteam ");
//arrayone.deletiteam_one_array(2);
// حذف القيمة مع ارجاع المصفوفة  باكملها لانها من نوع 
//int  يتطلب لها تحويل القيمة الى نوع جينرك وبعدها تحويلها الى مصفوفة من 

return (t[])(t)arrayone.deletiteam_one_array(2);
} 

//  دالة  الجمع للثلاث الدوال 
public void delete(){
  conf(data);//  دالة التحو ل  من  الثناية الى الاحادية 
  
t[] array=  deletone_array();// دالة الحذف 
arrayone.display();
    conversionToAraay2(array);//  دالة التحول من ثاني الى احاد 
    display();
  
}
}