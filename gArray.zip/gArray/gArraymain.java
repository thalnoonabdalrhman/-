
package gArray;

import java.util.LinkedList;//مكتبة من نوع لست  يعني مصفوفة من نوع لست 

import java.util.Scanner;
import list.node;//استدعاء للنود من مكان اخر بدلا من تعريفها 


public class gArraymain {

    public static void main(String[] args) {
        System.out.println("view the data :");

       byte opreation; 
       Scanner sc=new Scanner (System.in);
      
       AraayDg1 A1=new AraayDg1<>();//هذا يعتبر ابوجكت من نوع بياتنا غير محدده اذا تريد تحديدها اعملها داخل القوسين نص او رقم 
       AraayDg2 A2=new AraayDg2<>();

       do { 
            System.out.println("1_Enter the matrix to ArrayD1: ");
            System.out.println("2_Enter th martix to ArrayD2 :");
            opreation=sc.nextByte();
            switch (opreation) {
                case 1:
                    boolean found =true;
                    do {                        
                        
                    System.out.println("1- Enter data into a ArrakyD1  martix :");
                  System.out.println("2- disply data into ArrayD1 matrix :");
                    System.out.println("3- Delet the  from  the matrix :");
                        System.out.println("4- في حالة تريد الخروج من هنا إضغط 0");
                        switch (opreation=sc.nextByte()) {
                            case 1:
//                                System.out.println("Enter the sizes :");
//                                A1.init(sc.nextInt());
                                                              
                                
//                                A1.insert(15);
//                                A1.insert(20);
//                                A1.insert(30);
//                                A1.insert(70);
//                                A1.insert(15);
//                                A1.insert(10);
                                
                                 
//                                A1.insert(true);
//                               // A1.insert(new node(9));
//                                A1.insert(new node("thalnoon"));// يستقبل على حسب ما هيا معرفة النود 
//// لان النود عندي من نص
                              A1.insert("t");
                              A1.insert("t");
                              A1.insert("t");

//                             A1.insert(new LinkedList<String>().add("kllll"));
                                                              break;
                                case 2:
                                A1.display();

                                break;
                                case 3:
                               int o;     
                    while(opreation==3){
                    System.out.println("1- Delet without repetition");//بدون التكرار 
                    System.out.println("2- Delet with repetition");//مع التكرار 
                    
System.out.println("3- Delet with repetition with  the first  value exceeding :");//حذف مع تخطي اول قيمة 
System.out.println("4- Delet with repetition with  the seconed   value exceeding :");// حذف مع تخطي ثاني قيمة 
System.out.println("5- Delet with repetition with  the first  value exceeding the last  :");// حذف مع تخطي اول قيمة من الاخير 
//System.out.println("6- Delet with repetition with  the second  value exceeding the last :");// حذف مع تخطي ثاني قيمة من الاخير 
System.out.println("في حالة تريد العودة إضغط صفر 0 ");                       
System.out.println("6- display()");
switch (o=sc.nextByte()) {
                            case 1:
                                
                                 A1.deletiteam(123);
                               A1.display();
                                break;
                                case 2:
                                
                                 A1.deletiteam1("t");
                                 A1.display();
                                break;
                                case 3:
                                    A1.deletiteam3(123);
                                break;
                                case 4:
                           A1.deletiteam5("iT");
                                break;
                                case 5:
                            A1.deletiteam4("t");
                                break;
                                case 6:
                      A1.display();
                      break;
                            default:
                               
                         opreation=1;
                        }
                    
                    }
                                
                                break;
                            default:
                                found=false;
                                System.out.println("------------------------------");
                        }
                    
                    
                    } while (found);

                    break;
                case 2:
             boolean found1=true;
             do{
                     System.out.println("1- Enter data into a ArrakyD2  matrix :");
                     System.out.println("2- disply data into ArrayD2 matrix :");
                    System.out.println("3- Delet the  from  the matrix :");
                    System.out.println("4-  في حالة تريد الخروج إضغط صفر ");
                 switch (opreation=sc.nextByte()) {
                     case 1:
//                                                 A2.insert("ii");// 
                               A2.insert("uu");//إ 
                               A2.insert("i");//
                               A2.insert(999);//
                              A2.insert(666);// 
                              A2.insert(55);//
                              A2.insert(55);// 
                              A2.insert(555);//
                              A2.insert("kk");//
                               A2.insert(2);
                                A2.insert(20);
                                A2.insert(2);
                                A2.insert(2);
                                A2.insert(15);
                                A2.insert(1);
                                
                              A2.insert(555);// 
                     //         A2.insert(new node("jjjjjj"));// 
                              A2.insert("kk");// 
                              /// من نوع قائمة 
                              A2.insert("kk");// 
A2.insert(new LinkedList<String>().add("thlanoon"));
                              // A2.display();
System.out.println("enter tedelete");
A2.delete();
                              
                         break;
                         case 2:
                         A2.display();
                        A2.delete_list("kk");
                         break;
                         case 3:
                             int p;
                             while (opreation==3) {                                 
         System.out.println("1- Delet without repetition");//بدون التكرار 
         System.out.println("2- Delet with repetition");//مع التكرار 
          System.out.println("3- Delet with repetition the latest conversion ArrayD1 :");//مع التكرار  مع التحويل الى الاخير بإستخدام المصفوفة احادية
          System.out.println("4- Delet with repetition the latest conversion ArrayD2 :");//مع التكرار  مع التحويل الى الاخير بإستخدام مصفوفة ثنائية 

System.out.println("5- Delet with repetition with  the first  value exceeding :");//حذف مع تخطي اول قيمة 
System.out.println("6- Delet with repetition with  the seconed   value exceeding :");// حذف مع تخطي ثاني قيمة 
System.out.println("7- display ");
                                 System.out.println(" الخروج من العملية ");
//System.out.println("5- Delet with repetition with  the first  value exceeding the last  :");// حذف مع تخطي اول قيمة من الاخير 
//System.out.println("6- Delet with repetition with  the second  value exceeding the last :");// حذف مع تخطي ثاني قيمة من الاخير
                                 switch (p=sc.nextByte()) {
                                     case 1:
                         A2.deletiteam(999);    
                                         break;
                                         case 2:
                            A2.deletiteam3(555);   
                                         break;
                                         case 3:
                     A2.deletiteam7("uu");   
                                         break;
                                         case 4:
                     A2.deletiteam4(555,0);   

                                             
                                         break;
                                         case 5:
                    A2.deletiteam5("m",0);   
                                         
                                         break;
                                         case 6:
                                             System.out.println("****************");
                                         break;
                                         case 7:
                                         A2.display();
                                         break;
                                     default:
                                         System.out.println("eixt 0"); 
                                 opreation=1;
                                 }
                             }
                             break;
                     default:
found1=false;
                 }
             }while(found1);
                     break;
                default:
                
                
            System.out.println("REALY :");            }
        } while (true);
    }
    
}
