
package glist;
//  هذابتكون فيه دالة المين وكل التنفيذ 

import java.io.InputStream;
import java.util.Scanner;



public class listmain {
    public static void main(String[] args) {
        
   linkedlistidt li=new linkedlistidt<>();
   byte opreation ;
        do {  
            System.out.println(" hell in generic :");
            System.out.println("1-Enter the node ");
            
            System.out.println(" 2-display .");
            
            System.out.println(" 3-delet node iteam and pointe :");
            
            System.out.println(" 4-function find node ");//دالة للبحث عن نود معين 
            System.out.println(" 5-sizes of lenght at node :");// عدد النودات في القائمة  
            System.out.println(" 6-delet node and bot return ");//دالة حذف النود  وإعادة القيمة 

            System.out.println(" 7-add node at opstion :");// اضافة نود على خسب الموقع 
            System.out.println(" 8-delet node at opstion ");
            switch (opreation=new Scanner(System.in).nextByte()) {
                
                case 1 :{
                    boolean found =true;
                    
                    do {                        
                        
            System.out.println(" 1-Enter the node first :");//إضافة عناصر الى النود في البداية 
            System.out.println(" 2-Enter the node last :");//إضافة عناصر النود الى النهاية 
            System.out.println(" 3-Enter the node addafater :");//إضافة النود بعد قيمة معينة         
                        System.out.println("4- في خالة تريد الخروج  0");
            switch (opreation=new Scanner(System.in).nextByte()) {
                            case 1:
                                    System.out.println("entern iteam the node ");
                               li.addfirst(new node("level 2"));
                                break;
                                case 2:
                      li.addlist(new node(770320321)); 
                     li.addlist(new node(95));
                     li.addlist(new node("thalnoon"));


                      
                     //بوضع قيم الى داخل الهيد بدون وساطة ابوجكت 
                                
                                break;
                                case 3:
                  li.addafater(new node("abadlrhaman"),"thalnoon"); 
                  // كإننا اقول نوديوجد وسطه بيانات من نوع  نص 
                                
                                break;
                            default:
                                System.out.println("=-==-== ");
                                
                 found=false;
                        }
                    
                    } while (found);
                }
            break;
                case 2:{
              li.display1();}
            break;
                    case 3:{
                        
                   switch (opreation=new Scanner(System.in).nextByte()) {
                case 1 :
                    boolean found1 =true;
                    
                    do {                        
                        
             System.out.println(" 1-delet node at first :");//حذف من البداية 
            System.out.println(" 2-delet node at last :");//جذف من النهاية 
            System.out.println(" 3-delet node at afater :");//حذف بعد قيمة معينة
             System.out.println("4- في خالة تريد الخروج  0");
            switch (opreation=new Scanner(System.in).nextByte()) {
                            case 1:
                                    System.out.println("delet first "+ li.deletfirst());
                                
                                break;
                                case 2:
                                    System.out.println("delelt list :"+li.deletlast()); 
                     //بوضع قيم الى داخل الهيد بدون وساطة ابوجكت 
                                
                                break;
                                case 3:
                                    System.out.println("delet value "+li.deletvalue(95));
                  // كإننا اقول نوديوجد وسطه بيانات من نوع  نص 
                                
                                break;
                            default:
                                System.out.println("=-==-== ");
                                
                 found1=false;
                        }
                    
                    } while (found1);

            }}
                    break;
                case 4:{
                    System.out.println("node finde "+li.findeanode(new  Scanner(System.in).nextLine()));
        }  break;
                    case 5:{
           System.out.println("sizes "+li.sizes(li.head));
                    }
                    break;
                    case 6:{
                        //حذف بدوناعادة القيمة 
                    li.deletlast1();

                    }break;
                    case 7:{
                  li.insrtconditio(new node("ppp"), 3);
//li.insrtconditio(new node(new Scanner(System.in).nextLine()), new Scanner(System.in).nextByte());
//إستدعاء للدالة الأضافة حسب الموقع مع جعله اكثر دينميكة من خلال الإضافة من المستخدم 
                    }break;
                    case 8:{
//li.deletcondtion(new Scanner(System.in).nextInt());
                li.deletcondtion(4);
                    }break;
                default:
                    System.out.println(" error ");
                      
                        }
        
        } while (true);

























//       li.append("th");
//       li.append("ih");
//       li.append("jh");
//       li.append("lh");
//       
//li.display();
//li.addlist("oi");
//li.display();
//li.addafater("oo", 3);
//li.display();

//       linkedlistidt lis=new linkedlistidt();
//
//lis.addfirst(new node("ooooo"));
//lis.addfirst(new node("jjjjj"));
//lis.addfirst(new node("llll"));
//lis.addfirst(new node("pppp"));
//lis.addfirst(new node("nnnnn"));
//lis.display1();
//lis.insrtconditio(new node("88"), 2);
//lis.display();
    }

    
}

