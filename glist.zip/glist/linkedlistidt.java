package glist;

public class linkedlistidt<t> {
   // المسؤل عن العمل في كل شيء في ال اللنكد لست هو ال head
  //بنعرف الهيد
    node head;
    // الكنوستركتر بوضع في قيم الولية
    public linkedlistidt(){
    head=null;
    }
    
    // دالة التاكد من ان اللست فاضية او لا 
    public boolean isempty(){
    return head==null;
    }
//    // دالة الاضافة 
//    
//    //دالة الاإضافة الى البداية 
//    // اضلفة الاخير 
//    public void append(t data){
//    //بنقوم بنشاء او بإضافة نود جديدة 
//    node newnode=new node();
//      newnode.data=data;//هنا إضافة القيمة 
//
//    // هنا عرفت نود جديد 
//    //  الان بفحصهل اللسنت فاضية ام قد افي عناص مضافة 
//    if(isempty()){
//    head=newnode;
//   } else{
//        // نود التحرك من اجل اضافة في الاخير 
//        node team=head;
//        
//        while(team.next!=null){
//    team=team.next;
//        } 
//     
//    team.next=newnode;//بينتقل الى عند القيمة المضافة مؤخر 
//    // هنا ربطت الؤشر 
//    
//    } }  
//      //إضافة الى البداية 
//public void addlist(t data){
////نقوم بنشأ نود جديدة 
//node newnode=new node();
//newnode.data=data;// إضافة البيانات 
//newnode.next=head;//بأخذ السلسة الذي يوشر علينا الهيد واخلي النود الجديدة توشر عليها 
//head=newnode;// بعدها بخلي الهيد تؤشر على هذه النود الجديدة 
//}
//
//
//// إضافة بعد اي قيم تريدها 
// public void addafater1(t data,int opitton ){// بدخل القيمة والموقع الذي يريد فيه الاضافة 
//   //نقوم بإضافة نود جديدة 
//   node newnode=new node();
//   newnode.data=data;
//     if (opitton==0) {
//         //لو الموقع رقم صفر بيضها مباشرة يعني القاىمة فاضي 
//         addlist(data);
//         return;
//     }
// node team=head;
// // بعرف نود جديدة 
// //بعرف عدد من اجل التحرك الى ند قبل الموقع الذي رح اضيف فيه 
// int index=0;
//     while (team!=null&&index<opitton-1) {         
//       //-1 من اجل اتوقف قبل الموقع الذي رح اضيف فيه  
//     team=team.next;
//     index++;
//     }
//// بعمل شرط في حالة كان الموقع الذي حدده للنود كبير ولا يوجد الى عنده نود 
//if(team==null){
//    System.out.println("list is empty :");
//}else{
//newnode.next=team.next;// بخلي الموشر حق النود الجديدة يوشر على النود الذي رح اضي النود الجديدة جنبها 
////مع الذي بعدها برتبط اولا 
//team.next=newnode;// الان بخلي النو الذي فبل تؤشر على الذي ضفتها الان 
//
//}
//
// }
// public void display(){
// node team=head;
// while(team!=null){
// System.out.println(team.data+"--->");
//   team=team.next;
// }
//  System.out.println("null  ");
// }
// 
 
/////////////////////////////////////////////////////////////////////////////////////////////////////
// }هذا شغل الدكتور 
  //إضافة الى البداية 
    
   public void addfirst(node v){
    //  الان بفحصهل اللسنت فاضية ام قد افي عناص مضافة 
    if(isempty()){
   head=v;
    } else{
        
     
v.next=head;//بينتقل الى عند القيمة المضافة مؤخر 
 head=v;
  }  // هنا ربطت الؤشر 
 // اضافة الى الاخير 
 
   
    }
public void addlist(node v){
if(isempty()){
// في حالة كانت فاضية تعتبر اضافة للأخير 
addfirst(v);
// إستدعا دالة الإضافة الى البداية 
return;
}
// امشي الى اخر عتبة  في السلم 
node team=head;
while(team.next!=null)
{
team=team.next;
}
team.next=v;// اخرى قيمة وقفت عليها بربطها مباشرة مع النود الجديد
System.out.println("adaition sucess :");

}

///  البحث عن نود من اجل اربط  بعدها  
public node findeanode(t data){
// بعرف نود جديدة من اجل التنقل عللى عناصر النود
node team=head;
while(team!=null){// هنا بتصل الى الهاوية ما رح توقف عن النود الاخيرة 
if(team.data.equals(data)){
break;// لا يفضل عمل return
}
    team=team.next;
}
return team;
}
// اضافة اللى اي مكان 
 public void addafater(node v,t data){
    // بشوف لوهيا فارغة بطبع بأنها فارغة واخرج
     if (isempty()) {
         System.out.println("list is isempty :");
         return;
     }
     node find=findeanode(data);
  ///  بعمل دالة البحث عن نود    
     if(find!=null){//بترجع ليا الموقع الذي فيه موقع النود الذي رح اضيف من بعدها
        v.next=find.next;//بخلي القمة الجديد تمسك السلسة الذي بعد النود الذي وجدتها 
        find.next=v;//النود الذي وقفت عندها تساوي السلسة  الذي ارتبطة الان 
        //  بخلي النود الجديدة تؤشر على التود الذي بعد ان وجدتها 
        // ربطة السلسة الذي بعد 
        //بخلي النود الذي وجدتها ترتبط مع قيمة النود الجديدة الذي ربطها مع السلسة الذي بعط
        
        System.out.println("addition sucess ");
        return;
     }
     System.out.println("ELement not found :");


 }
 
// دالة العرض 
 public void display1(){
     for(node team=head ;team!=null;team=team.next){
         System.out.println("["+team.data+" "+"]--->");
     }
 }
///دالة الحذف ال linked list 
 //تقابل pop is stack 
 // بخليها تحذف وترجع ليا قيم من نوع نود 
//حذف اول عنصر  
 // تمثل enqueue  اول عنصر دخله بتعامل معه فقط 
 
 
 public node deletfirst(){
 //  بشوفها اذا هيا فارغة او لا 
 if(isempty())
 return null;//td phgm  ;hkj thvym fdv[u gdh thqd 
 // في حالة لا انا اريد حذف الول موقع 
 node team=head;
 head=head.next;
 team.next=null;// تم تحريهها من القيود الخاصة بالأرتباط 
 
 return team;// تعيدالقيمة المحذوفة 
 }
//  حذف اخرى فيمة تسمى او تقابل 
 //تمثل pop to stack
 // دابة الحذف مع اعادة قيمة 
 public node deletlast(){
  node team=head;

     if(isempty()){
     return null;}
 // بتحرك الى النود الا خيرة في حالة كانت فnاضية 
 //node team=new node();
 
 // في حالة احتمال كانت وجود قيمة واحدة داخل  النود 
 if(team.next==null)// في حالة كانت اول قيمة هيا اول نود يعني الموشر حقها بنل برسله الى الدالة الحذف من البداية 
 {
 return deletfirst();

 }
 while(team.next.next!=null){// يعني وقوف قبل النود الاخيرة بنود فبلها يعني وقفنا بثنتين نودات 
  team=team.next;
 }
 // بنأخذ النود الاخيرة 
 node te=team.next;// الان الؤشر حقي يشاور على النود الاخيرة 
 team.next=null;// خليت المؤشر يترك الثيمة ويشاور على null 
 
 
 return te;// يرجع الموقع المحذوف 
 // مخزن اخرى  قيمة القيمة الفعلية التي تم حذفها 
 
 }
 

 //  بدون اعادة القيم 
void deletlast1(){
  node team=head;

     if(isempty()){
     return ;
     
     }
 // بتحرك الى النود الا خيرة في حالة كانت فnاضية 
 //node team=new node();
 
 // في حالة احتمال كانت وجود قيمة واحدة داخل  النود 
 if(team.next==null)// في حالة كانت اول قيمة هيا اول نود يعني الموشر حقها بنل برسله الى الدالة الحذف من البداية 
 {
  deletfirst();// or head =null;//غذاكانت نود واحدة فقط 
 return;//  توقف 
 
 }
 while(team.next.next!=null){// يعني وقوف قبل النود الاخيرة بنود فبلها يعني وقفنا بثنتين نودات 
  team=team.next;
 }
 // بنأخذ النود الاخيرة 
 node t=team.next;// الان الؤشر حقي يشاور على النود الاخيرة 
 team.next=null;// خليت المؤشر يترك الثيمة ويشاور على null 
 
 
 
 }
//  دالىة البحث 
node findevalue(t value){
// نود جديدة من اجل ان اتحرك براحتي 
node team=head;
while(team.next!=null){
 if (team.data.equals(value)) {
    break;
 }   
team=team.next; 
}

return team;
}
// دالة حذق قيمة معينة 
//تعيد قيمة  
node deletvalue(t value){
if(isempty()){
    System.out.println("list is value ");
    return null;
}
// بإستخدام دالة البحث 
node resul=findeanode(value);
// الان باشوف القيمة الراجعة من دالة البخث 
if (resul==null) {
        System.out.println(" list is empty :");
return null;
}// هنا عملية البحث 
// متغير يمشي الى قبلها  من اجل الحذف 
node  ss=head;
// هنا ان مابضع قيمة حتى لتعامل مع القيمة الموجدة مباشرة 
//
    while (ss.next!=resul) {//بتحرك الى ان اصل الى قبل القيمة تمام
        //الان بيكون هل المؤشر حق الريسزلت يوشر على القيمة الموجدة 
        ss=ss.next;
    }
 ss.next=resul.next;//بخلي القيمة الذي موجدة ترتبط مع القيمة الموجد في البحث البحث موجد فيه القيم من بعد القيم الموجدة الى القيمة الإخير فقط 
 resul.next=null;
 return resul;//  تعيد القيمة المراد حذفها 
}

/// دالة الحجم 
int sizes(node n){

if(n==null){
   return 0;
}
return 1+sizes( n.next);// إرجاع مع إستدعاء يعتي يجلس يستدعي وبعده يجمع يضل يستدي النودات 

}


// تدخل لها الموقع وترجع هيا الرقم 
//دلة تبحث عن نود معين على حسب الرقم 
node findevalue1(int opstion ){// تبحث على حسب الرقم وترجع النود 
// نود جديدة من اجل ان اتحرك براحتي 

node t=head;
int index=0;
while(t.next!=null&&opstion-1>index){
t=t.next;
++index;



}
return t;
}

//دالة الإضافة بإستخدام الدوال 
// دالة إضأفة النود حسب الموقع المحدد من المستخدم 
void insrtconditio(node v,int sizes)// دالة اضافة النود حسب الموقع المحدد بيكون المدخل من المستخدم االنود الجديدة 
{
 System.out.println("enter the opstion :"+sizes);
    if(sizes==0){
   addfirst(v);
    }else{
        
  node find=findevalue1(sizes);//دالة تبحث على حسب الموقع وترجع ليا النود 

if(find==null){
        System.out.println("linked list is em[pty :");
        return;
}
//إستخدام دالةإلإضافة علي حسب القمة التي بحث عنها 
//بيدخل هذه ومعه القسمة التي حصلها ومعه القمة الجديدة من اجل إضافتها 
//بيدخل يبحث ويتأكد من القبيمة ويضيف بعدها 

///هنا عملت عملية تحويل للفوند من اجل ترجع من جينرك واقدر استقبلها في دالة الحذف 
addafater(v,(t) find.data);
//هنا تقدر ترسل النود او قيمة النود بس مع الكستنج 
//هنا الفزوس الثاني ضرور ي يرجع يستقبل قيم من جينرك
//هذه الدلة يوجد فيها دالة من اجل القيمة التي اريد ادخل بعدها ببحث عنه واضيف فيها د
//دالة بحث وإضافة بنفس الوقت 
}}


// دالة الحذف حسب الموقع بإستخدم دوال 
void deletcondtion(int sizes){
    System.out.println("enter the opstion :"+sizes);
    if(sizes==0){
        System.out.println("is empty :");
        return;}
    /// بعرفها داخل نود من اجل استطيع التعامل معها 
node find =findevalue1(sizes);// ادخلت الرقم بيروح الى دالة البحث ويرجع القيمة 
//الان باجي احذف القيمة 
//دالة الحذف حسب القيمة 
if(find==null){
        System.out.println("linked list is em[pty :");
return;
}
//دالة الحذف حسب القيمة المدخلة 
deletvalue((t) find.data);//ارسلت لها القمية وليس النود لانه دالة الدالة بيبحث من جديد ويحذف القيمة 
//  هنا عملت لها عملية كستنج من اجل احولها الى نوع جينرك من اجل اقدر استقبل في دالة الحذف 

}
 







// بدون إستخدام اي دوال 
// احذف النود حسب الموقع المدخل 
//void deletcontion(int sizes){
//    
//    if(sizes==0){
//head=null;
//// لو وجد عنصرين كيف بيكون 
//node team=head;
//head=head.next;
//team.next=null;
//    }else{
//node tea=head;
//int index=0;
//while(tea.next!=null&&sizes-1>index){
//tea=tea.next;
//++index;
//
//}
//if(tea==null){
//        System.out.println("linked list is em[pty :");
//s=team.next;
//team.next=team.next.next; 
//// العنصر الذي بعد الذي حذف 
//System.out.println(" ------"+team.data);
//
//    }
//return s;
//}}




//    //هذه بدون إستخدام دوال    
//void insrtconditio(node v,int sizes)// دالة اضافة النود حسب الموقع المحدد بيكون المدخل من المستخدم االنود الجديدة 
//{
//    
//    if(sizes==0){
//   addfirst(v);
//    }else{
//        
////node t=head;
////int index=0;
////while(t.next!=null&&sizes-1>index){
////t=t.next;
////++index;
////
////}
//if(t==null){
//        System.out.println("linked list is em[pty :");
//        return;
//}
////v.next=t.next;  
////t.next=v;
//}}

        }
