/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dlist;

/**
 *
 * @author a
 */
public class dnode {
  int data;
  dnode prev;
  dnode next;
 public dnode(){
 next=prev=null;
 // قيمة اولية وتكون ب null  
 }
 
public dnode(int data){
//this.data=data;
//next=prev=null;
this();// أستدعيت الكلاس الاول من اجل الا اكرر العمل نفسه
this.data=data;

}
}
