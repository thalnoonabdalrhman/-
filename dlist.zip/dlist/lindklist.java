/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dlist;

/**
 *
 * @author a
 */
public class lindklist {
   dnode head,tial;
  public lindklist() 
  {
  head=tial=null;
  }
  
 //الدوال في اللست 
  boolean isempty(){
  //بصيك هل هيا فاضية او لا 
  return (head==null)&& (tial==null);
  }
  
///إَإضافة الى البداية
  public void addfrist(dnode d){
      if (isempty()) {
          head=tial=d;
          //طباعة للتأكد 
        //  System.out.println("head ="+head.data);
          return;
      }
  d.next=head;//بربط النكست حق  النود الجديدة بقيمة القيمة 
  head.prev=d;//بربط البريفيس  حق القديمة مع قيمة النود الجديد الى عند القيمة 
  head=d;//بحرك موقع  الهيد  الى البداية 
    // System.out.println("head +"+head.data);
  }

//إضافة الى النهاية 
 public void addlast(dnode d){
     if (isempty()) {
         head=tial=d;
         return;// في حالة كانت فاضي 
     }
     /////////////////////-1
 //التحرك الى اخر موقع او باصيف عبر  التل مباشر tail
// dnode team=head;
// while(team.next!=null){
// team=team.next;
// 
// }
// //هنا بربط 
// team.next=d;//اخر قيمة وقفت عندها بربط النكست مع قيمة القيمة الجديدة 
// d.prev=team;//بربط البريفيس حق النود الجديدة مع قيمة النود القيمة 
// //احرك التل tail 
// tial=d;
 ////////////////////////////-2
 //او مباشرة 
 //tial واقف عند اخر قيمة باضيف الى عنده واحركه 
 tial.next=d;
 d.prev=tial;
 tial=d;//تحريك التل 
 
 }


 
 ///دالة البحث 
 public dnode foundafter(int data){
     if (isempty()) {
         System.out.println("Doubly linked list is empty ");
         return null;
     }
//التحرك للبحث على العنصر  
dnode team=head;

     while (team.next!=null) {
         
      if (team.data==data) {
           break;
         }  
      team=team.next;
     }  
return team;
 }

 
 // البحث من اجل اضافة قيمة  قيمة قبل 
 
 public dnode fundbafor(int data){
     if (isempty()) {
         System.out.println("Doubly linked list is empty ");
         return null;
     }
//التحرك للبحث على العنصر  
dnode team=head;
 //System.out.println("taila "+tial.data);
     while (team.next!=null) {         

         team=team.next;
     }  
     while(team.prev!=null){
     if (team.data==data) {
      break;
     }  
System.out.print("datat "+team.data);
team=team.prev;
     }
return team;
 }

 
 
 
 
//دالة الإضافة على حسب العنصر المدخل 
 public void addafater(dnode d,int data){
 if(isempty()){
 head=tial=d;
 return ;}
 // البحث عن العنصر 
 
dnode ruslt=foundafter(data);// القيمة الراجعة من البحث 

if (ruslt!=null) {// القيمة التي رجعت ضروري لا نتساوي فارغة 
     d.next=ruslt.next;//تعني القيمة الجديدة تربط القيمة بعد اقيمة التي وجدتها 
     d.prev=ruslt;// البرفيس حق النود الجديدة ترتبط مع قيمة النود الذي تريد الإضافة بعدها 
     ruslt.next.prev=d;
     ruslt.next=d;

 
     System.out.println("data "+d.data);
     System.out.println("ruslt "+ruslt.data);
    
     }
 
 
 }
 
 
////إضافة قبل قيمة 
 // برجع انتقل من النهاية 
 public void addbafore(dnode d,int data){
     if (isempty()) {
         addfrist(d);
     return;
     }
    //  dnode rslt=fundbafor(data);
//تطلع نفسها 
 dnode rslt=fundbafor(data);
     System.out.println("rsltbafore "+rslt.data);

if(rslt!=null){
 d.next=rslt;
d.prev=rslt.prev;
rslt.prev.next=d;
rslt.prev=d;
///  في مثال اخر طبقها بواسطة دوال 
     System.out.println("//d.next=rslt; ="+rslt.prev.data);
}
 
 }
 
 ///دالة الإضافة حسب رقم محدد 
         //دالة تبحث عن رقم وترجع ليا ا لنود 
public dnode foundnumber(int opstion){
     if (isempty()) {
         System.out.println("Doubly linked list is empty ");
         return null;
     }
//التحرك للبحث على العنصر  
dnode team=head;
int index=0; //عداد يعد الى قبل الموقع بواحد لان اللست تبداء من صفر 
     while (team.next!=null&&index<opstion-1) {         
            team=team.next;
            index++;
     }  
return team;//بيرجع ليا النود  على حسب الرقم الذي طلبته
 }
 

//دالة الإضافة 
public void addopstion(dnode d,int opst){
    if (isempty()) {
        System.out.println("is empty :");
    }
    if (opst==0) {
        addfrist(d);//دالة إضافة للبداية 
    }
//دالة الإضافة على حسب النود 
dnode reslt=foundnumber(opst);
    System.out.println("rselt33"+reslt.data);
addafater(d, reslt.data);//إضافة نود على حسب القيمة الراجعة من الرسيلت 


}
    

///////////////دالة الحذف من البداية 
public dnode  deletfirst()
{

if(isempty()){
    System.out.println(" is empty :");
return null;
}
dnode team=head;
head=head.next;
//الان رجعت الى النود الذي قبل لا تقةل مرة ثانية rslt.next.prive اصل انت واقف على النكست لانك حركتها قبل 
head.prev=null;

return team;//إرجاع للقيمة المحذوفة



}

// حذف من النهاية 
public dnode  deletlast()
{

if(isempty()){
    System.out.println(" is empty :");
return null;
}
////ام تنتقل نفس ماتقل دائما الى الاخير 
////tail موجود التل نحذفه بوسطه لكن هناك فرق بين الحذف منالتل والتنقل بعملهم الاثنيين
//dnode team=tial;
//tial=tial.prev;//بيرجع خطوة للورى
//tial .next=null;// القمة حق النكست تكون بنل 
//
//return team;//إرجاع للقيمة المحذوفة
////////////////////////////////////////////////-1
////طريقة اخرى 
////التحرك للبحث على العنصر  
dnode team1=head;
dnode rt=null;
     while (team1.next!=null) {         
         team1=team1.next;
     }
 rt=team1;
 //  النكست حق النود الذي قبل ضرور  ترجع فاضي لان اصلها هكذا 

 //  اولا بتعمل هذه الخطوة لان هذه الخطوة تقدر من خلالها تصل الى النكست وترجعه فاضي 
team1.prev.next=null;//;هنا كأننا حددت البريفيس حق النود الذي اريد حذفها  كأننا عند البرفيسف حق النود الذي اريد حذفه
 team1=team1.prev;// بنقل البفريس خطوة للخلف 
tial=team1;
return rt;
}

//دالة تحسب عدد النودات 
public int tosizednode(){
dnode team=head;
int count=0;
while(team!=null){
team=team.next;
++count;
}
return count;
        }


// حذف على حسب القيمة المراد حذفها 
public void deletafater(int data){//بستخدم دالة البحث  
    if (isempty()) {
        System.out.println("is empty :");
    return ;
    }
    // بعمل شرط في حالة كانت النود اقل من 
  
    //دالة البحث
 dnode rslt=foundafter(data);
    System.out.println("rselt ="+rslt.data);
    if (rslt==null) {// في حالة القيمة الراجعة لست بنل بفاضي 
        System.out.println(" is not found ");
   return;
    } 
    //في حالة كانت اول نود 
   dnode team=head;
      if (team.data==data) {
          deletfirst();//  حذف من البداية 
    return;
      }
      // في حالة اخر نود 
      while (team.next!=null) {        
        team=team.next;
    }
      if (team.data==data) {
          deletlast();//  الحذف من الخير 
      return;
      }
        rslt.prev.next=rslt.next;// البرفيس يؤشر على النو د السابقة  والنكست اصبحت تعرف بالمؤشر الخارج من النود السابقة 
    //=rslt واقفة عند النود المراد حذفها  والر rslt .next بيوقف عند النود الذي بعدها بيتحول المؤشر 
    
    // في حالة يريد الحذف لقيمة قبل اول قيمة 
    
    if (rslt.next!=null) {
        
    
    rslt.next.prev=rslt.prev;// rslt.next بنتقل من النود المراد  حذفها الى النود الذي بعدها  والنود هذه الذي وقفت عندها المؤشر حقة يوشر 
    }//rslt.prev يعني المؤشر الخارج من النود المراد حذفها الى الذي قبلها الى عند القيمة 
rslt.prev=null;//تأكيد فصل القيمة 
rslt=null;//تاكيد الفصل  
}




// دالة الحذف للقيمة بعد القيمة الذي اعطيتها 
public void delettafeter(int data){
    //عند اخر قيمتين يطلع غلط  كيف اجزع على هذا الغلط 
 if (isempty()) {
        System.out.println("is empty :");
    return ;
    }
 dnode rslt=foundafter(data);
    System.out.println("rslt data "+rslt.data);
    if (isempty()) {
        System.out.println("is empty ");
    return ;
    }
    //  الفكرة اغير قيمة الريسلت فقط للقيمة الذي بعد القيمة الذي وجدتها الدالة هيا نفس دالة الحذف 
    // استدعيت دالة تحذف القيمة المراد تحذف قيمتها وادخلت القيمة الذي بعد القيمة التي وجدتها 
    deletafater(rslt.next.data);

}


//
public void deletbafore(int data){
    //عند اول قمتين يطلع غلط كيف اجزع على هذا الغلط 
 if (isempty()) {
        System.out.println("is empty :");
    return ;
    }
 dnode rslt=foundafter(data);
    System.out.println("rslt data "+rslt.data);
    if (isempty()) {
        System.out.println("is empty ");
    return ;
    }
    // الفكرة إستخدم دالة حذف مجودة معيا لموقع deletafater 
    // إستخدم دالة البحث للحذف حسب القيمة المدخلة ادخلها القيمة الراجعة من البحث من ترجعيها اللى القيمة الذي الذي قبلها 
    //  وتحذف طبيعي من دون اي قلل 
    // او استخدم الدالة هنا مرة ثانية بس هذا يأخذ وقت  ويأخذ وقت 
    deletafater(rslt.prev.data);

}


public void deletobstion(int opstion){
 if (isempty()) {
        System.out.println("is empty :");
    return ;
    }
    if (isempty()) {
        System.out.println("is empty ");
    return ;
    }
    
 dnode rslt=foundnumber(opstion);
  System.out.println("rslt data "+rslt.data);
    deletafater(rslt.data);
}





























public void display(){
//متغير مؤقت من اجل اتحرك من خلاله 
dnode teamfront=head;//للطباعة من الأمام 
System.out.print("[");
while(teamfront!=null)//بتحرك حتى اصل الى فراغ 
{
    System.out.print(" "+teamfront.data+"<---__>");
teamfront=teamfront.next;//التحرك 
//next الى عندما تصبح تساوي فاضي 
}
    System.out.println("]\n");
//    
//    
//dnode teambook=tial;//للطباعة  من الخلف  
//System.out.print("[");
//while(teambook!=null)//بتحرك حتى اصل الى فراغ 
//{
//    System.out.print(" "+teambook.data+"<---__>");
//teambook=teambook.prev;//التحرك 
////prve الى عندما تصبح تساوي فاضي 
//}
//    System.out.println("]");
//

}












}
