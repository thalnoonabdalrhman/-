/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dlist;

import java.util.Scanner;
import list.listmain;

/**
 *
 * @author a
 */
public class miandlist {
    public static void main(String[] args) {
      boolean found=true; 
        lindklist dlis=new  lindklist();

        do {            
        System.out.println("1-  Enter th addfirst :");
        System.out.println("2- Enter th addlist :");
        System.out.println("3-  Enter th addafter  :");
        System.out.println("4-  Enter th addbefore  :");
        System.out.println("5-  Enter th add_opstion  :");
        System.out.println("6-  Enter th deletfirst  :");
        System.out.println("7-  Enter the deletlast ");
        System.out.println("8-  Enter th deletvalue  :");
        System.out.println("9-  Enter th deletafter  :");
        System.out.println("10-  Enter th deletbafore  :");
        System.out.println("11-  Enter th deletopstion  :");
        System.out.println("12-  display  ");
        System.out.println("13-  getsize  :");
        System.out.println("14- Enter exit");
        
        byte op;
            switch (op=new Scanner(System.in).nextByte()) {
                case 1:
   dlis.addfrist(new dnode(9));
   dlis.addfrist(new dnode(11));
   dlis.addfrist(new dnode(13));    
                    break;
                   case 2:
   dlis.addlast(new dnode(16));
   dlis.addlast(new dnode(18));

                    break;
                    case 3:
   dlis.addafater(new dnode(66),9);
   dlis.addafater(new dnode(559),11);

                    break;
                case 4:
       dlis.addbafore(new dnode(99), 11);
       dlis.addbafore(new dnode(100), 99);
             
                    break;
                 case 5:
        dlis.addopstion(new dnode(55),3);
         dlis.addopstion(new dnode(88),1);

                    break;
                    case 6:
   System.out.println("dlis.deletfirst() =="+dlis.deletfirst().data);
              
                    break;
                    case 7:
  System.out.println("dlis.delelist() =="+dlis.deletlast().data);
              
                    break;
                    case 8:
       dlis.deletafater(18); 
       dlis.deletafater(100);
                    break;
                    case 9:
          dlis.delettafeter(18);//يطلع خطى في هذه الخالة
        
                    break;
                    case 10:
          dlis.deletbafore(18);
           
                    break;
                    case 11:
       dlis.deletobstion(5);
              
                    break;
                    case 12:
        dlis.display();      
                    break;
                    case 13:
                        System.out.println("dlis.tosizednode() ="+dlis.tosizednode());  
                    break;
                    case 14:
                    found=false;
                    break;
                default:
                    System.out.println("Retry :");            }
        } while(found);

//        
//        
////       dlis.addfrist(new dnode(6));
////      dlis.addfrist(new dnode(7));
////      dlis.display();
//
//    
//   dlis.addfrist(new dnode(9));
//      dlis.addlast(new dnode(10));
//            dlis.addlast(new dnode(11));
//
//      dlis.display();
//       dlis.addafater(new dnode(13),9);
//     dlis.display();
//    dlis.addafater(new dnode(14),13);
//     dlis.display();
//    dlis.addopstion(new dnode(17),3);
//      //System.out.println("dlis.deletfirst() =="+dlis.deletfirst().data);
//    dlis.display();
//      // System.out.println("dlis.delelist() =="+dlis.deletlast().data);
//dlis.display();
//dlis.fundbafor(5);
//dlis.addbafore(new dnode(90), 14);
////dlis.deletafater(11);
//dlis.deletlast();
// dlis.deletbafore(13);
// //dlis.display();
//
////dlis.delettafeter(17);
// //dlis.deletobstion(5);
//dlis.display();
    }
 
}