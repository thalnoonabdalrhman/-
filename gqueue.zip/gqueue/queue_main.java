/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gqueue;

import java.util.Scanner;

/**
 *
 * @author a
 */
public class queue_main {
   
    public static void main(String[]args){
//  linked_queue queue = new linked_queue();
//        System.out.println("queue :");
//        queue.enqueue(new node("t"));
//        queue.enqueue(new node("u"));
//        queue.enqueue(new node("o"));
//        queue.enqueue(new node("p"));
//      queue.displayqueue();
//        System.out.println("delet queue :"+queue.dequeue().data);
//              queue.enqueue(new node("l"));
//
//      queue.displayqueue();
//      System.out.println("delet queue :"+queue.dequeue().data);
//      queue.displayqueue();
//  

//
////

//بإستخدام المصفوفات 

//qeueu_Array_liner q=new qeueu_Array_liner();
//        System.out.println(" ddd"+q.data.length);
//        System.out.println(""+ q.unmberitemaqueue());
//q.enqueue(2);
//q.enqueue(3);
//q.enqueue(4);
//q.enqueue(5);
//q.enqueue(6);
//q.display();
//        System.out.println("dequeue :"+q.dequeue());
//        System.out.println("front "+q.getfront());
//                System.out.println("rear "+q.getrear());
//q.display();
//                q.deletiteam(3);
//q.display();
//        System.out.println(""+ q.unmberitemaqueue());





//بإستخدام المصفوفات 


//    
//  queue_Array_creical qc=new queue_Array_creical();
//        System.out.println(" ddd"+qc.data.length);
//qc.enqueue(1);
//qc.enqueue(2);
//qc.enqueue(3);
//       System.out.println(qc.dequeue());
//qc.enqueue(4);
//qc.enqueue(5);
//qc.enqueue(6);
//        System.out.println(qc.dequeue());
//
//        System.out.println(qc.dequeue());
//qc.display();  
//    
//        System.out.println("front :"+qc.getfront());
//        System.out.println("rear :"+qc.getrear());
//        qc.deletqueueiteam(5);
//        System.out.println("front :"+qc.getfront());
//        System.out.println("rear :"+qc.getrear());
//        qc.display();
//          
//        
//




        
        qeueu_Array_liner qli=new qeueu_Array_liner();
         queue_Array_creical qcr=new queue_Array_creical();
        linked_queue queue = new linked_queue();
        int  i=0;
       byte op; 
       boolean foundq=true;
       do {   
            
            System.out.println("1-Enter the Array queue :");
            System.out.println("2-Enter the queue linked list:");
            System.out.println("3-Enter to colse :");
            op=new Scanner(System.in).nextByte();//عملية إدخال 
            switch (op) {
               case 1:
                   boolean foundlin_cri=true;
                   do {   
                       System.out.println(" 1 -Array liner queue :");
                       System.out.println(" 2 -Array cricaler queue:");
                       System.out.println(" 3 -DO you want to come back :");
                           switch (op=(new Scanner(System.in).nextByte())) {
                               case 1:
                                   boolean foundliner=true;
                                   // عندنا باشوفها فيها بعض الغلاكاتى 
                                   do {                 
                                       
                      System.out.println("1 - Enter the iteams in  liner queue :");
                      System.out.println("2 -delet the iteams in  liner queue :");
                      System.out.println("3 - view the first front in liner queue  :");
                     System.out.println("4 - view the frist rear in liner queue  :");

                      System.out.println("5 - display the iteams in liner queue  :");
                       System.out.println("6 - delet the iteams to be usde by the user in liner queue :");
                       System.out.println("7 -number value in queue liner ");
                       System.out.println("8 - DO you want to come back :");
                        System.out.println("[[[[");
                         switch (op=(new Scanner(System.in).nextByte())) {
                             case 1:
                                 System.out.println("Enter iteam :");
                                 qli.enqueue("thalnoon ");
                                 qli.enqueue("level 3 ");
                                 qli.enqueue(95 );
                                 qli.enqueue("exelent");


                                 break;
                                 case 2:
                                     System.out.println("dequeue :"+qli.dequeue());                                     
                                 break;
                                 case 3:
                                     System.out.println("front value :"+qli.getfront()); 
                                 break;
                                 case 4:
                                  System.out.println("rear value :"+qli.getrear()); 

                                 break;
                                 case 5:
                                 qli.displayl();
                                 break;
                                 case 6:
                                     System.out.println("Enter the iteam to delet :");
                                 qli.deletiteam(95);
                                 break;
                                 case 7:
                                     System.out.println("number :"+qli.numberitemaqueue());
                                 break;
                                 case 8:
                                 foundliner=false;
                                 break;
                         default:
                                   System.out.println("Retry :");
                             
                                          }
                                   
                                   } while (foundliner);
            
                                               break;
                                   case 2:
                                     boolean foundcri=true;
                                   do {                                       
                                       
                      System.out.println("1 - Enter the iteams in  criclar queue :");
                      System.out.println("2 -delet the iteams in  criclar queue :");
                      System.out.println("3 - view the first front in criclar queue  :");
                     System.out.println("4 - view the frist rear in criclar queue  :");

                      System.out.println("5 - display the iteams in criclar queue  :");
                       System.out.println("6 - delet the iteams to be usde by the user in criclar queue :");
                       System.out.println("7 -number value in criclar queue:");
                       System.out.println("8 - DO you want to come back :");
                        System.out.println("");
                         switch (op=(new Scanner(System.in).nextByte())) {
                             case 1:
                                 System.out.println(" iteam :");
                                 qcr.enqueue("thalnoon ");
                                  qcr.enqueue("abdalrhamin ");
                                 qcr.enqueue("it");
                                 qcr.enqueue("level ");
                                 qcr.enqueue("2");
                                 qcr.enqueue("tiaz ");

                                 break;
                                 case 2:
                                     System.out.println("dequeue :"+qcr.dequeue());                                     
                                 break;
                                 case 3:
                                     System.out.println("front value :"+qcr.getfront()); 
                                 break;
                                 case 4:
                                  System.out.println("rear value :"+qcr.getrear()); 

                                 break;
                                 case 5:
                                 qcr.display();
                                 break;
                                 case 6:
                                     System.out.println("Enter the iteam to delet :");
                                 qcr.deletqueueiteamc("it");
                                 break;
                                 case 7:
                                     /// عدد عناصر الكيو 
                                   System.out.println("number :"+qcr.numberqueueacrical());
                                 break;
                                 case 8:
                                 foundcri=false;
                                 break;
                         default:
                                   System.out.println("Retry :");
                             
                                          }
                                   
                                   } while (foundcri);
                                   break;
                                   case 3:
                                 foundlin_cri=false;
                                   break;
                           default:
                    System.out.println("Retry :");
                           }
                   } while (foundlin_cri);
                   
                   break;
                   case 2:
                    boolean foundli=true;
                       do {                           
    System.out.println(" 1- Enter the node  in qqueue from enqueue :");
    System.out.println(" 2- delet the node in queue from dequeue :");
   System.out.println(" 3- display node in queue :");
    System.out.println(" 4- DO you want to come back :");
    switch (op=(new Scanner(System.in).nextByte())) {
          case 1:
              System.out.println(" node ");
              queue.enqueue(new node("name"));
               queue.enqueue(new node("thalnoon"));
              queue.enqueue(new node("it"));
              queue.enqueue(new node(2));
              queue.enqueue(new node("level"));

              break;
              case 2:
              queue.dequeue();
              break;
          case 3:
              queue.displayqueue();
              break;
              case 4:
              foundli=false;
              break;
          default:
                 System.out.println("Retry :");
      }
                       } while (foundli);
                   
                    break;
                    case 3:
                    foundq=false;
                    break;
               default:
                   System.out.println("Went out :");
              break;
            }
            
        } while (foundq);

    }
}