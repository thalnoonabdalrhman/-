/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gqueue;

/**
 *
 * @author a
 */
public class linked_queue<t> {
   // كلاس اللنكد كيو تطبيق مبدا اللنكد كيو في اللنكد لست 
 // المبداء الداخل اول  الخارج اولا 
 // يكون معك دالتين  
    // بيكون معك دالة للإضافة من النهاية 
   // دالة الحذف من البداية 
    // يدخل من النهاية ويخرج من البداية 
    node head;
    public linked_queue(){
    head=null;
    }
    
    boolean isempty(){
    return head==null;
    
    }
    // دالة إضافة من النهاية 
    
 void enqueue(node en){
if(isempty()){// في حالة كانت فارغة ولا يوجد شيء تعني إضافة للناهية 
   head=en;// بدل ماكان فاضي رجع الان يحمل قيمة 
   return;// بعدها بكسر الحلقة 
}
 //  يعني يوجد فيها عناصر 
 // بعرف نود من اجل ان اتحرك   الى الخير الى عند النود الأخيرة
 node team1=head;
 while(team1.next!=null){// في حالة الأضافة ضروري مأوقف عند نود اخيرة ما اصل الى الهاوية 
  team1=team1.next;
 
 }
 // الذي رح يخرج من هنا هوا اخر نود بخلي المؤشر حقهل يرتبط مع النود الجديدة 
team1.next=en;
 }
 // دالة الحذف من البداية 
 node dequeue(){
 //بتأكد من حالة اللست 
 if(isempty()){
         System.out.println("queue is empty :");
 return null;
 }
 // في حالة لسيت فاضية بحذف مباشرة من البداية 
 //متغير امسك به السلسة من اجل احذف اول نود 
 node team2=head;
 head=head.next;
 team2.next=null;// هنا كإننا حذفت المؤشر المؤقت 
 return team2;
 }
 //دالة طباعة 
 void displayqueue(){
 node team3=head;
 while(team3!=null){
     System.out.print(team3.data+" -->"+"\t");
 team3=team3.next;
 }
 System.out.println("null ");
 }
  
}
