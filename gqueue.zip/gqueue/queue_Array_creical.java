/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gqueue;

/**
 *
 * @author a
 */

// الكيو الحلقي 
public class queue_Array_creical<t> {
     t data[];
    int front;
    int rear;
int couter=0;

    public queue_Array_creical(){
    data=(t[])new Object[7];
    front=rear=0;//يبداء من صفر وجودموقع يضل فيه الفرنت
    }

    @Override
    // 
    public String toString() {
        return  "data=" + data + '}';
    }
    
public queue_Array_creical(int size){
data=(t[])new Object[size];
front=rear=0;

}
//ر  يوجد صيغ عديدة الى الكنوستكتر يسهل الاستخدام
boolean isempty(){
return rear==front;// الموقع صفر لا يتم فيه اضافة ولا شيء 
//في حالةكانت الفرننت والرير في نفس المكان 

}
boolean isfull(){
    
return  (rear+1)%data.length==front;
//اذا كان العنصر الذي امامك هو الفرنت هيا ممتلئة 

}


void enqueue(t iteam){
if(isfull()){
    System.out.print("stack is full");
    return;
}
rear=(rear+1)%data.length;// الكيو الحلقي ينقص بعنصر عن الحجم الاصلي الموقع صفر ليس فيه اي قيمة 
 data[rear]=iteam;
 couter++;
 //   System.out.println("rear ="+rear);
}
 
t dequeue(){
    if (isempty()) {
        System.out.println("queue is empty  :");
        return null;
    }
    //  ليشت قلت اول يزيد وبعدها يرجع القيمة  السببب لانه لوقلت له يرجع القيم رح يرجع القيمة وموقعه سالب واحد 
    // والقيمة عند سالب واحد لا توجد 
    --couter;
return data[front=(front+1)%data.length];
// هنا بيجي عند اول  عند اول مرة  بيشوف الموقع وقاصد زاد وبحذف 

}



t getfront(){
    if (isempty()) {
 return null;
    }
    // الموقع صفر هومكان وقوف الفرنت 
  
//قيمة اول موقع هيا data[front=((front+1)%data.length) // لا تضع الفرنت بيساوي قيمة  الفرنت زائد واحد لانه بيغير قيمة الفرنت يعني لا تدخلت 
//لا تدخل مساوى     
    return data[((front+1)%data.length)];// اول قيمة وال الفرنت زائد واحد لانه واقف عند مكان محذوف  
}//هنا الفرنت بيضل عاده عند الصفر ولا تحرك من مكانه لان بيضل  عند قيمة محذوفة 


t getrear(){
    
    if (isempty()) {
 return null;
    }
//return data[rear=(rear+1)]
    //rear =reat+1 %data.lengh//  في حالت عملت كذا انت بتغير قيمة الرير

return data[(rear+1)%data.length];
}


void display(){
    //int n=6;
    if (isempty()) {
        System.out.println("queue is empty :");
        return;
    }
//front هنا دائم بيكون زائد واحد لانه يبداء من االسالب  تمام 
//عندما اريد استخدامه في اي مكان ازود على قيمة بواحد مرة واحدة فقط 
for (int i = front+1; i!=(rear+1)%data.length ; i=(i+1)%data.length) {// لان الفرنت يبدء من السالب 
    //الفرنت زائد واحد لانه واقف عند مكان محذوف 
   // System.out.print("oo+ppp  ");
    System.out.print("["+" "+data[i]+"]");
      
    }
////اخرى قيمة
//لانه اخر قيمة بيقول القيمة لا تساوي القيمة بيخرج لان القيمة حق الرير تساوي الفرنت بس القيمة ما طبعها
System.out.println("["+data[rear]+"]");
    System.out.println("");
    
}

void deletqueueiteamc(t iteam){
    
    for (int i = front+1; i!=rear ; i=(i+1)%data.length) {// لان الفرنت يبدء من السالب 
   
         if (data[i].equals(data[front])) {//  القيمة المراد حذفها هيا قيمة الفرنت
            front=(front+1)%data.length;
            break;
        }
        if (data[i].equals(iteam)) {
        rear--;
        couter--;// من اجل عدد العناصر  
          System.out.println("is found :");
          
          for (int j = i; j != rear; j=(j+1)%data.length ){
              data[j]=data[j+1];
          }
          
          
    // لان الموقع صفر ولا تنضاف فيه اي قيمة  يبقي للشيخ فرنت 
    
    }
    }
    if(data[rear].equals(iteam)){// القيمة المراد حذفها هي اخر قيمة 
            data[rear]=data[((rear+1)%data.length)];
            rear--;
            return;
         }
     //هنا في هذه الحالة يعني كانك تقول الفرنت والرير تساوو انا بخلي الرير اخر موقع فيه لاننا قد نقلت قيمته الا بنقل له قيمة 
     // باقول موقع الرير الاخير بشل اول موقع في الكيو كانه بيبداء من الصفر تمام 
    System.out.println("real list"+(data[rear]=data[(rear+1)%data.length]));

}

public int numberqueueacrical(){
return couter;


}
}
