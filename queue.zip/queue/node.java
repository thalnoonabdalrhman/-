/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package queue;

/**
 *
 * @author a
 */
public class node {
     //كلاس النود وفيه كل الأدوات 
    String data;//متغير بضع فيه قيمة البيانات 
    node next;//هذ اصل المؤشر
    // هذا  الكنوستركتر 
    public node(){
    next=null;// بوضع قبم اولية للمؤشر لانه اول مرة بيكون يشاور على null
    }
    public node(String data){
    this.data=data;// من اجل افرق مابين القيمة الذي قي الكلاس 
    // والبرميتر المرسل 
    //هذا يعتبر الحارس الاساسي لكل ابوجكت 
   this.next=null;
   
    }
    public node(String data,node next){
    this.data=data;
    this.next=next;
    
    }
    //يعني يوجد عدة انواع من الكنوستركتر 
    //  اكثر من صيغة للكنوستركتر من اجل التسيهيل 
 /// اذا كنت اريد اشتغل في وسط النود بدون استدعاء الدالة node.next 
//نقول الابوجكت مباشرة لانحتاج الى استدعاء الدالة بواسطة دالة جهازة 

    @Override
    public String toString() {// موجودة في الكلاسات اسمها ت to string 
        return "[ "+data+ '}';
 }
 /// في حالة اريد التعامل مع التم استخدمه كابوجكت بدون استدعاء البيانات 
    
}
