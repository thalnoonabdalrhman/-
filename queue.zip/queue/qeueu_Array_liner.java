
package queue;

public class qeueu_Array_liner {
 // الكيو الخطية    
    int data[];
    int front;
    int rear;
    
    public qeueu_Array_liner(){
    data=new int[10];
    front=rear=-1;
    }
public qeueu_Array_liner(int size){
data=new int[size];
front=rear=-1;

}
//ر  يوجد صيغ عديدة الى الكنوستكتر يسهل الاستخدام
public boolean isempty(){
return front==rear;
//في حالةكانت الفرننت والرير في نفس المكان 

}
boolean isfull(){
return rear==data.length-1;
}

// تكون من نوع بpublic  من اجل اقدر اشوفها من كلاس اخرى 

public void enqueue(int iteam){
if(isfull()){
    System.out.println("stack is full");
return;
}
data[++rear]=iteam;
}
 
public int dequeue(){
    if (isempty()) {
        System.out.println("queue is empty  :");
        return -1;
    }
    //  ليشت قلت اول يزيد وبعدها يرجع القيمة  السببب لانه لوقلت له يرجع القيم رح يرجع القيمة وموقعه سالب واحد 
    // والقيمة عند سالب واحد لا توجد 
    
return data[++front];// برجع القيمة وبعدها بزود على قيمة الفرنت حتى تنتقل من الموقع صفلر الى الموقع الذي بعده 
//ينطلق وقت الاضافة في حالة اريد حذف برتفع من الموقع الى الذي بعده عن طريق front
//عن طريق الرير  بنقص من الرير 

}

//تحسب عدد العناصر في   queue 
public int numberitemaqueue(){
return rear-(front+1);//الفرنت يبداء من سالب واحد 
}

public int getfront(){
    if (isempty()) {
 return -1;
    }
return data[front+1];// اول قيمة وال الفرنت زائد واحد لانه واقف عند مكان محذوف  
}


public int getrear(){
    
    if (isempty()) {
 return -1;
    }
return data[rear];
}


public void display(){
    if (isempty()) {
        System.out.println("queue is empty :");
    }
//front هنا دائم بيكون زائد واحد لانه يبداء من االسالب  تمام 
//عندما اريد استخدامه في اي مكان ازود على قيمة بواحد مرة واحدة فقط 
for (int i = front+1; i <= rear; i++) {// لان الفرنت يبدء من السالب 
    //الفرنت زائد واحد لانه واقف عند مكان محذوف 
    System.out.print("["+" "+data[i]+"]");
        
    }
    System.out.println("");
}

// دالة بحث عن عنصر 


// حذف عنصر من موقع معين 



// حذف بدون تكرار 
public void deletiteam(int iteam){
    if (isempty()) {
        System.out.println("queue is empty :");
        return;
    }
   boolean found=false;
    for (int i =front+1; i <= rear; i++) {// ركز الفرنت دائما زاىد واحد داىما 
        if (data[i]==iteam){
            found=true;
        
  
        
            //بحول العنصر مباشرة الا الاخير 
            for (int j = i; j <rear; j++) {//اصلا الرير هو نفسه قد يجي ناقص واحد 
                data[j]=data[j+1];
           
            
            }
     data[rear]=0;//
       rear--;
        break;
        }}
           
    
    
}
/// الحذف مع التكرار 
public void deletiteam_m(int iteam){
    if (isempty()) {
        System.out.println("queue is empty :");
        return;
    }
   boolean found=false;
    for (int i =front+1; i <= rear; i++) {// ركز الفرنت دائما زاىد واحد داىما 
        if (data[i]==iteam){
            found=true;
        
  
        
            //بحول العنصر مباشرة الا الاخير 
            for (int j = i; j <=rear; j++) {//اصلا الرير هو نفسه قد يجي ناقص واحد 
                data[j]=data[j+1];
           
            
            }
     data[rear]=0;//
       --rear;
      //
      //  في حالت كانت القيمة متابعدة بيحذف القيم الممكررة بدون رجوع طبيعي 
      // في حالت القيم المكررة قيمة جنب قيمة ضرور  الرجوع 
      i--;//  الرجوع من اجل التأكد 
      //  break;
        } 
       
    }
           
    
    
}



//void deletiteam(int iteam){
//    if (isempty()) {
//        System.out.println("queue is empty :");
//        return;
//    }
//   boolean found=false;
//   int t=0;
//    for (int i =front+1; i <= rear; i++) {// ركز الفرنت دائما زاىد واحد داىما 
//        if (data[i]==iteam){
//            found=true;
//        t=i;
//  break; // مثل لعنصر واحد   لو تريد مع التكرار بتبعد هذه
//        }}
//    if (found) {
//        
//            //بحول العنصر مباشرة الا الاخير 
//            for (int j = t; j <rear; j++) {//اصلا الرير هو نفسه قد يجي ناقص واحد 
//                data[j]=data[j+1];
//            }
//            //  الموقع الاخير بسبب الرير تبقي كما هيا يعني اخر قيمة التحويل لا يصلها بعملها يدوي 
//            //اذا انت تريد التأكد افعل السمة وتابع الحل بالرسم 
//             rear--;
//            data[rear]=data[t];
//        System.out.println("iteam is sueccessfull :");
//    }else{
//            
//        System.out.println("iteam in queue not found ");
//    }
//    
//    
//    
//}
}

