/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package queue;

/**
 *
 * @author a
 */

// الكيو الحلقي 
public class queue_Array_creical {
     int data[];
    int front;
    int rear;
    
    public queue_Array_creical(){
    data=new int[6];
    front=rear=0;//يبداء من صفر وجودموقع يضل فيه الفرنت
    }
public queue_Array_creical(int size){
data=new int[size];
front=rear=0;

}
//ر  يوجد صيغ عديدة الى الكنوستكتر يسهل الاستخدام
boolean isempty(){
return rear==front;// الموقع صفر لا يتم فيه اضافة ولا شيء 
//في حالةكانت الفرننت والرير في نفس المكان 

}
boolean isfull(){
    
return  (rear+1)%data.length==front;
//اذا كان العنصر الذي امامك هو الفرنت هيا ممتلئة 

}


void enqueue(int iteam){
if(isfull()){
    System.out.print("stack is full");
    return;
}
rear=(rear+1)%data.length;// الكيو الحلقي ينقص بعنصر عن الحجم الاصلي الموقع صفر ليس فيه اي قيمة 
 data[rear]=iteam;
    System.out.println("rear ="+rear);
        System.out.println("iteam ="+iteam);

}
 
int dequeue(){
    if (isempty()) {
        System.out.println("queue is empty  :");
        return -1;
    }
    //  ليشت قلت اول يزيد وبعدها يرجع القيمة  السببب لانه لوقلت له يرجع القيم رح يرجع القيمة وموقعه سالب واحد 
    // والقيمة عند سالب واحد لا توجد 
    
return data[front=(front+1)%data.length];
// هنا بيجي عند اول  عند اول مرة  بيشوف الموقع وقاصد زاد وبحذف 
}



int getfront(){
    if (isempty()) {
 return -1;
    }
    // الموقع صفر هومكان وقوف الفرنت 
//قيمة اول موقع هيا data[front=((front+1)%data.length) // لا تضع الفرنت بيساوي قيمة  الفرنت زائد واحد لانه بيغير قيمة الفرنت يعني لا تدخلت 
//لا تدخل مساوى     
//System.out.println("front  ="+front);
    return data[((front+1)%data.length)];// اول قيمة وال الفرنت زائد واحد لانه واقف عند مكان محذوف  
}//هنا الفرنت بيضل عاده عند الصفر ولا تحرك من مكانه لان بيضل  عند قيمة محذوفة 


int getrear(){
    
    if (isempty()) {
 return -1;
    }
    //rear =reat+1 %data.lengh//  في حالت عملت كذا انت بتغير قيمة الرير
return data[(rear+1)%data.length];
}


void display(){
    //int n=6;
    if (isempty()) {
        System.out.println("queue is empty :");
        return;
    }
//front هنا دائم بيكون زائد واحد لانه يبداء من االسالب  تمام 
//عندما اريد استخدامه في اي مكان ازود على قيمة بواحد مرة واحدة فقط 
for (int i = (front+1)%data.length; i!=(rear+1)%data.length ; i=(i+1)%data.length) {// لان الفرنت يبدء من السالب 
    //الفرنت زائد واحد لانه واقف عند مكان محذوف 
    //System.out.print("oo+ppp  ");
    System.out.print("["+" "+data[i]+"]");
      
    }

////اخرى قيمة
//لانه اخر قيمة بيقول القيمة لا تساوي القيمة بيخرج لان القيمة حق الرير تساوي الفرنت بس القيمة ما طبعها
//System.out.println("["+data[rear]+"]");
    System.out.println("");
    
}

void deletqueueiteam(int iteam){
    
    for (int i = (front+1)%data.length; i!=(rear+1)%data.length ; i=(i+1)%data.length) {// لان الفرنت يبدء من السالب 
      //  System.out.println("rear ="+(rear+1)%data.length);
        if (data[i]==data[front]) {//  القيمة المراد حذفها هيا قيمة الفرنت
            front=(front+1)%data.length;
            break;
        }
        if(data[rear]==iteam){// القيمة المراد حذفها هي اخر قيمة 
            data[rear]=data[((rear+1)%data.length)];
            rear--;
            return;
         }
        if (data[i]==iteam) {
        
          System.out.println("is found :");
          for (int j = i; j != rear; j=(j+1)%data.length){
              System.out.println("rear "+rear);
              // بتكون شفيتنج الى عند اخرى موقع في الرير وياخذ الموقع صفر  وبنقص وكانني تجاهلت الموقع وعند الاضافة بيرجع الموقع لان بهيئ قينة 
              // الرير 
              System.out.println("rear leanht"+(rear+1)%data.length);
              System.out.println("j ="+j);

               data[j]=data[j+1];
             // System.out.println("datafront "+data[front+1]);
             // System.out.println("front1 ="+front);
             // System.out.println("data "+data[j]);
          }
                  rear--;

          }
    }
    
     //هنا في هذه الحالة يعني كانك تقول الفرنت والرير تساوو انا بخلي الرير اخر موقع فيه لاننا قد نقلت قيمته الا بنقل له قيمة 
     // باقول موقع الرير الاخير بشل اول موقع في الكيو كانه بيبداء من الصفر تمام 
    System.out.println("real ;list"+(data[rear]=data[(rear+1)%data.length]));

   // System.out.println("front 2="+front);
}
// دالة حساب عدد العناصر في الكيو الدائري
public int frf(){

return (rear-front+data.length)%data.length;
}

}
