/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Array;

//import java.text.Normalizer;
import java.util.Scanner;
import gArray.AraayDg2;//  لبوجكت الجينرك 
import gArray.AraayDg1;
/**
 *
 * @author a
 */
import queue.qeueu_Array_liner;
// استدعاء الكلاس
// اسم البكج  دت اسم الكلاس الموجود فيه 



public class ArrayD2 {
    int[][] data;
    int countrow,countcol;
//int col;
   public   ArrayD2() {
        data = new int[3][3];
//        row=data.length;
//        col=data[data.length-1].length;
//this.row=row;
//this.col=col;
countrow=countcol=-1;//هذه من اجل احدد الصفوف والعمود عندما اضيف 

    }

    boolean isfull(){
   // System.out.println("co  "+countcol);
    return (countcol==data[data.length-1].length) &&(countrow==data.length);// اخر صف من المصفوفة هل قيمة العمود عنده يعني انا في الاخير 
         //في كانت في اخر موق في وكذالك في العمود 

   ///هنا شرط التحقق من ان المصفوفةممتلئة 
   // في حالة العمود يساوي اخر  قيمة للعمود في اخر صف 
   // كذالك في حالة الصف هو اخر صف 
         
  
  //return false;
   }
    boolean isempty(){
return countrow==-1&&countcol==-1;
}


  public  void insert(int iteam) {
        
  //      System.out.println("Enter the element arry :");
//        
//        for (int i = 0; i < row; i++) {
//            for (int j = 0; j < col; j++) {
//
//                data[i][j] = new Scanner(System.in).nextInt();
//            }
//            System.out.println("data.lenght "+data.length);
//        }

    
        if (isfull()) {
            System.out.println("is full");
           return;
        }
        // هذا الشرط من اجل اول مرة بدخل اعمل اضافة بيشوف اذا هيا فاضي بيحول قيمة الصق والعمود الى صفر 
         if (isempty()) {// في حالةكانت فارغ يعني انا باضيف اليها 
System.out.println("iififffffffffffffff");
            countcol++;//من اجل تفادي غلط اول مره 
          countrow++;
         }
                        
            
           // }
           // هذا الشرط يتاكد من اننا لم اصل الى اخر المصفوةفة 
            if (countrow!=data.length) {// في حالة لم اتعدي حجم المصفوفغة 
           //
//                System.out.println("cornt "+countcol);
//                System.out.println("row "+countrow);
                data[countrow][countcol++]=iteam;// بزود على قيمة العمود كل مرة الان انا قد زوت قيمته فوق لو عملت الزيادة قبل بيخلي الموقع
               // الاول فاضي 
               // يضيف الى الصف  مع تحريك العمود عند كل اضافة 

                    }
            // شرط في حالة كان عند اخر قيمة  في العمود من اجل انتقل الى الصف الذي بعده وارجع العمود بصفر 
           if(countrow<=data.length-1){
            if (data[countrow].length==countcol) {//اذاكان الصف الذي انا واقف فيه يساوي يساوس قيمة العمود الذي مشي للعنده 
             countcol=0;
             countrow++;
               // System.out.println("counf t"+countrow);
         }}//else{
            

//                     for (int i = 0; i <=countrow; i++) {
//                    for (int j = 0; j <=countcol; j++) {
//                System.out.println("iteam "+data[i][j]);
//                }
// System.out.println("iteam "+data[0][0]);
// System.out.println("iteam "+data[0][1]);
//           System.out.println("iteam "+data[1][0]);
//                 System.out.println("iteam "+data[1][1]);

            //}
            }
           

    void display() {
        System.out.println("araay elemen the are  :");
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {

                System.out.print(data[i][j] + "\t");
            }
            System.out.println("");
        }
  
  }
 // 1 حذف بدون تكرار 
   //تحذف اول قيمة من اول المصفوفة وجدها حتى لو وجد تكرارت مارح يحذف التكرارت
void deletiteamt_without_re(int iteam){
// ابحث عن العنصر 
// اضع قيمة العنصر  يصفر 
//يخول العنصر  الى اخر شيء في المصفوفة 
int indexrow=-1;
int indexcol=-1;

boolean found=false;
        
    
X:for (int i = 0; i <data.length; i++) {
        for (int j = 0; j < data[i].length; j++) {

    if (data[i][j]==iteam) {
    indexrow=i;
    indexcol=j;
    found=true;
    //data[i][j]=0;
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
           System.out.println("prign");
break X;

    }
        
        }
    
    }
    if (found) {
        // ناقص  واحد لانه اذاوقف عند العنصر الاخير ويريد الذي الذي بعده يطلع غلط 
        
        for (int i = indexcol; i <data[indexrow].length-1; i++) {
                
            
            data[indexrow][i]=data[indexrow][i+1];
        }
         data[indexrow][data[indexcol].length-1]=0;
    }else{
        System.out.println("element is not found :");
    }
}


//2 الحذف مع التكرار
void deletiteam3_wiht_r(int iteam){
// ابحث عن العنصر 
// اضع قيمة العنصر  يصفر 
//يخول العنصر  الى اخر شيء في المصفوفة 
int indexrow=-1;
int indexcol=-1;

boolean found=false;
 int inex=0;  
 int array[]=null;
    
for (int i = 0; i <data.length; i++) {
        for (int j = 0; j < data.length; j++) {
    if (data[i][j]==iteam) {
    indexrow=i;
    indexcol=j;
    found=true;
    data[i][j]=0;
   //حولت قيمة الموقع الى صفر 
   
  // array=new int[++inex];
 for (int i1 = indexcol; i1 <data[indexrow].length-1; i1++) {
                
       //  if (indexcol<=inex) {
         
     
      //   array[0]=data[indexrow][i1+1];}
         data[indexrow][i1]=data[indexrow][i1+1];
        }
     /// data[indexrow][]=array[inex];  
        System.out.println("array :"+array[0]);
       data[indexrow][data[indexcol].length-1]=0;  
    --j;
    //برجع اتأكد هل القيمة مازالت موجودة 
    }
      }
    
    }
    if (found) {
        System.out.println("تم التعديل والحذف للعنصر "); 
       
    }else{
        System.out.println("element is not found :");
    }
}



//
//// هذه نفس الذي بعدها بس منظم 
//// الحذف بإستخدم المفوفة الثانئية 
////في حالة اريد ان اعمل إزاحة للعنصر الذي حولت قيمتة بصفر الى أخرى المصفوفة 
//public void deletintema(int iteam)
//{
//    int crom=0;
//     int ccolw=0;
// boolean found=false;
//    for (int i = 0; i < data.length; i++) {
//        for (int j = 0; j < data[i].length; j++) {
//            if(iteam==data[i][j]){
//                
//            found=true;
//            crom=i;
//           ccolw=j;
//                for (int k = crom; k < data.length; k++) {
//                for (int l = ccolw; l < data[i].length-1; l++) {
//                       data[k][l]=data[k][l+1]; 
//                       System.out.println("data "+data[k][i]);
//                    }
//                    if (crom<=data.length) {
//                        ccolw=0;
//                        data[crom][data[crom].length-1]=data[++crom][ccolw];
//                    System.out.println("data "+data[crom][data[crom].length]);
//
//                    }
//                }
//                data[data.length-1][data[data.length-1].length-1]=0;
//            j--;
//            }
//        }
//   
//    }
//
//}
// بإستخدام المصفوفة الثانية 
public void deletiteam4_use_2D(int iteam){
int c1=0;
  int c2=0;
    boolean found=false;
    System.out.println("");
    System.out.println("");
for (int i = 0; i <data.length; i++) {
        for (int j = 0; j < data[i].length; j++) {

    if (data[i][j]==iteam) {
    c1=i;//هناوضعت  موقع الصف الذي يوجد فيه العنصر  
    c2=j;//هنا وضعت  موقع العمود الذي العنصر موجود فيه 
    
    found=true;
    for (int i1 = c1; i1 <data.length ; i1++) {//هناببداء من الصف الذي وفقت فيه الى حجم المصفوفة بالكامل 
          for (int j1 = c2; j1 < data[i].length-1; j1++) {  // عدد الأعمدة في الصف الذي انا وافق فيه
       data[i1][j1]=data[i1][j1+1];//هنا عملية تحويل للصف الاول بالكامل  يعني بيمشي في العمود الاول والثاني حتي يصل الى الاخير وهكذا 
        System.out.print("h = "+data[i1][j1]+" ");
   
          }
          c2=0;//عندما يخرج برجع قيمة العمود بصفر لان العمود في الصف الثاني بيبداء من صفر 
          c1=i1+1;// هنا بزود على قيمة الصف من اجل انتقل الى الصف الثاني 
      if(c1<=data.length-1){//لم يكون السي اصغر بيدخل ينفذ اخر مرة مار يدخل ينفذ لانه بيطلع اكبر من الحجم المطلوب 
          //هنا بتأكد من اجل اخر عملية لا تدخل هنا بتأكد هل الصف اقل او يساوي اخر موقع في المصفوفة ناقص واحد 
          // يعني الذي قبل الأخير 
          //من اجل اذا زادت قيمة الصف على المصفوفة ما يدخل ويطلع غلط 
  data[i1][data[i1].length-1]=data[c1][c2];//هنا تعني اخر عنصر في الضف الاول من العمود الاخير بيساوي اول عنصر من الصف الثاني العمود الأول 

      }
        }
data[data.length-1][data[data.length-1].length-1]=0;
// هنا تعني اخر عنصر من المصفوفة في الصف الاخير 
//في اخر عمود من هذا الصف 
//[data[data.length-1].length-1]تعني اخر عمود من الصف الاخير 

         System.out.println("");
        
j--;// من اجل الأكد هل احتذف العنصر ام لا 
    }
        }}
}    


// الحذف مع التكرار بشرط ترك العنصر الاول من التكرارت 

public void deletiteam5_with_r_1(int iteam){
// ابحث عن العنصر 
// اضع قيمة العنصر  يصفر 
//يخول العنصر  الى اخر شيء في المصفوفة 
int indexrow=-1;
int indexcol=-1;

boolean found=false;
int c=0;        
 
for (int i = 0; i <data.length; i++) {
        for (int j = 0; j < data[i].length; j++) {

    if (data[i][j]==iteam) {
       if(c>=1){// التأكد هل هو اول تكرار ام اخرى تكرار 
    indexrow=i;
    indexcol=j;
    found=true;
    data[i][j]=0;
   //حولت قيمة الموقع الى صفر 
 for (int i1 = indexcol; i1 <data[indexrow].length-1; i1++) {
                
            
            data[indexrow][i1]=data[indexrow][i1+1];
        }
        data[indexrow][data[indexcol].length-1]=0;  
    --j;
    //برجع اتأكد هل القيمة مازالت موجودة 
    }
   c++;
    }
      }
    
    }
    if (found) {
        System.out.println("تم التعديل والحذف للعنصر "); 
       
    }else{
        System.out.println("element is not found :");
    }
}
/////  تحويل العنصر الى الخير بإستخدام ثلاث دوال 
//// الحذف مع تحريك العنصر الذي تم حذفه الاى الخير بإستخدام المصفوفة الثنائية 
////حولها الى مصفوفة احادية واحذف ثم رجعها الى مصفوفة ثنائية 
//public void deletiteam6(int iteam){
//int teamarray[]=new int[data.length*data[data.length-1].length];// قيمة الصف في اخر قيمة للعمود 
//// ليش ناقص واحد لانه بيزيد على حجم المصفوفة بيكون مش موجود العمود 
////  لانه هنا بيقول العمود الثالث  عند اخر صف في المصفوفة لان المصفوفة حجمها بيبداء من واحد 
////ولو وقفت عند اخر حجم يعتبر مش موجود لانها تبداء من صفر 
//    System.out.println(" sizs ="+data.length*data[data.length-1].length);
//
//    int count=0;
//    for (int i = 0; i < data.length; i++) {
//      for (int j = 0; j < data[i].length; j++) {
//      teamarray[count]=data[i][j];
//         ++count; 
//     }
//    }
//
////حذف مع التكرار 
//int index=-1;
//boolean found=false;
//for (int i = 0; i <teamarray.length; i++) {
//   if (teamarray[i]==iteam) {
//    index=i;
//    found=true;
//    teamarray[i]=0;
//   //حولت قيمة الموقع الى صفر 
//   //بعده بكسر الحلقة 
//    //في هذه الحالى يحذف جميع البيانات التي تكررت ويضع بدلها صفر لكن الترتيب ليس تمام 
//   for (int j = index; j <teamarray.length-1; j++) {
//          
//      teamarray[j]=teamarray[j+1];
//      }
//    teamarray[teamarray.length-1]=0;
//
//   --i;//التأكد من العناصر هل موجودة اكثر من  مرة 
//   
// //  i--;
//  // sizse--;
//  //هذه صحيحة مئة بالمئة متبقي كيف احذ ف القيم الاخيرة كامل 
//        }
//    }
//int count1=0;
//    if (found) {
//        System.out.println("teamarray");
//        for (int i = 0; i < count; i++) {
//            System.out.print(" "+teamarray[i]);
//        }
//        for (int i = 0; i < data.length; i++) {
//      for (int j = 0; j < data[i].length; j++) {
//      data[i][j]=teamarray[count1];
//          ++count1;
//     }
//    }
//    }else{
//        System.out.println("element is not found :");
//    }
//
//
//}

// دالة التحويل الى مصفوفة احادية 
public int[] data_one_array(){
//  مصفوفة لحادية بخجم المصفوفة الثنائية 
int array1iteam[]=new int[data.length*data[data.length-1].length];
// حجم الصف في حجم العمود
int count=0;
    for (int i = 0; i < data.length; i++) {
      for (int j = 0; j < data[i].length; j++) {
      array1iteam[count]=data[i][j];
         ++count; 
     }
    }
    
    for (int i = 0; i < count; i++) {
        System.out.println(" Araay one da : "+array1iteam[i]);   
    }
    System.out.println("is conversion is successfuly :");
return array1iteam;//بترجع قيم من نوع مصفوفة من اجل اتعامل مع المصفوفة 
}


// دالة حذف العناصر في المصفوة الثانئية 
public int[] deletiteam_one_array(int[] data,int iteam){

boolean found=false;
for (int i = 0; i <data.length; i++) {
   if (data[i]==iteam) {
    int index=i;
    found=true;
    data[i]=0;
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
    //في هذه الحالى يحذف جميع البيانات التي تكررت ويضع بدلها صفر لكن الترتيب ليس تمام 
   for (int j = index; j <data.length-1; j++) {
          
      data[j]=data[j+1];
      }
    data[data.length-1]=0;

   --i;//التأكد من العناصر هل موجودة اكثر من  مرة 
   
 //  i--;
  // sizse--;
  //هذه صحيحة مئة بالمئة متبقي كيف احذ ف القيم الاخيرة كامل 
        }
    }
    if (found) {
        for (int i = 0; i < data.length; i++) {
        System.out.println(" Araay one delet :"+data[i]);   
    }
        System.out.println("iteama is delet ");
        
    }else{
        System.out.println("element is not found :");
    }

// بيعيد ليا المصفوفة التي حذفها 
return data;

}

// دالة تعيد القيم الى مصفوفة ثنائية 
public void conversionToAraay2(int []deletaraay1){
    System.out.println(" المصفوفة في وضع التحول ");
      int count=0;  
        for (int i = 0; i < data.length; i++) {
      for (int j = 0; j < data[i].length; j++) {
      data[i][j]=deletaraay1[count];
          ++count;
     }
    }


}
// دالة الحذف الى الإخير بإستخدام الثلاث الدوال 
public void deletiteam_with_r_use_3_function(int iteam){
int array1conversion[]=data_one_array();// استدعاء دلة التحويل //  دالة التحويل من ثنائي الى احاد
//طباعة للتأكد من انه تم النحويل 
//for(int i=0;i<=array1conversion.length-1;i++){
//    System.out.println("ARRAY 1 "+array1conversion[i]);
//    
//     
//}
    // استدعاء لدالة الحذف
 int array1[]=deletiteam_one_array(array1conversion,iteam);//دالة  الحذ الاحادية 
  // استدعا لدلة تحويل المصفوفة الى ثنائية 
  conversionToAraay2(array1);//  دالة التخول من احادي الى ثنائي 
    


}
// دالة تحذف العناصر المكررة بشرط ترك العنصر الاخير مع    التكرار 
// مع التحويل الى اخر الصف الموجود
public void deleteiteam_with_r_lestE1(int iteam){
    int rowindx=0;
    int colindx=0;
    int count=0;
    
        for (int i = data.length-1; i >= 0; i--) {
        for (int j = data[i].length-1; j>=0; j--) {
            if (iteam==data[i][j]) {
              if (count>=1) {
                    
                 data[i][j]=0;
                rowindx=i;
                colindx=j;
                
          for (int k =colindx ; k<data[rowindx].length-1; k++) {
                  
             data[rowindx][k]=data[rowindx][k+1];
                  
          }
          data[rowindx][data[rowindx].length-1]=0;      
                
             
              /// من اجل الا يرجع عند اول مرة تم الحذف 
          if(count>=1){
      //      ++j;// هذا بزيد من اجا اعادة المقارنة مرة اخرى بين القيم الذي عمل لها شيفتنج 
              }
              }
           count++;
            
        }
        }}
//

}



/// الحذف بشرط ترك العنصر الثاني من التكرارا 
public void delet_whit_r_2(int iteam){
    
    
    int rowindex;
    int colindex;
    int c=1;
    for (int i = 0; i < data.length; i++) {
        for (int j = 0; j < data[i].length; j++) {
            if (iteam==data[i][j]) {
                if (c!=2) {
                    // لايدخل في حالت القيمة الثانية 
                
                rowindex=i;
                colindex=j;
                
                 for (int k = colindex; k < data[rowindex].length-1; k++) {
                    data[rowindex][k]=data[rowindex][k+1];
                }
              data[rowindex][data[rowindex].length-1]=0;
                 --j;// لوكانت بعد شرط السي ضروري هذا لتفادي الخطى  من اجل الا يرجع عند الموقع الذي لااريد حذفه 
                 
                }
                c++;
            }
   
        }
    }


}







//  دالة تقوم بالتالي 
// حذف العناصر المكررة وازاحة  العناصر الى اخر المصفوفة بإستخدام 
// التحويل من ثنائية الى الكيو الخطي 
/// الحذف مع التكرارا بإستخدام   الكيو الخطي 
//التحوي من الثائية الى الكيو الخطي 

// 
public void deletiteaminqueue(){
    
qeueu_Array_liner ql=new qeueu_Array_liner();


    for (int i = 0; i < data.length; i++) {
        for (int j = 0; j < data[i].length; j++) {
            // الدوال المراد استطعائها تكزن من نوع public 
            ql.enqueue(data[i][j]);
        }
    }
    // دالةالطباعة 
    ql.display();
    // الحذف 
    // 
    System.out.println("enter the values delete ");
   ql.deletiteam_m(new Scanner(System.in).nextInt());
   // حذف من الكيو الى داخل المصفوفة 
    while (!ql.isempty()) { //  الشرط موجود في الكيو في حالت كانت فارغة        
        // في حالت ليست فارغة 
      for (int i = 0; i < data.length; i++) {
        for (int j = 0; j < data[i].length; j++) {
            // الدوال المراد استطعائها تكزن من نوع public 
             
            data[i][j]=ql.dequeue();//  حذف من الكيو اتللا المصفوفة 

        }
    }
    }

}

//// الحذف مع  التكرر بشرط  تركت العنصر الاخير  من التكرارات بشرط الازاحة الى الاخير 
//// مع التحرك  الى اخر المصفوفة 
//
//public void deletintema_list(int iteam)
//{
//    int rom=0;
//     int colw=0;
//     int c=0;
// boolean found=false;
//    for (int i = data.length-1; i>=0 ; i--) {
//        for (int j =  data[i].length-1; j >=0; j--) {
//            if(iteam==data[i][j]){
//           //        data[i][j]=0;
//
//              //  if (c>=1) {
//                
//            found=true;
//            rom=i;
//           colw=j;
//                for (int k = rom; k <data.length; k++) {
//                for (int m = colw; m <data[rom].length-1; m++) {
//                       data[k][m]=data[k][m+1]; 
//                       System.out.println("data "+data[k][i]);
//                    }
//                
//                     rom=k+1;
//                    colw=0;
//
//                    if (rom<data.length-1) {
//                        
//                        data[k][data[k].length-1]=data[rom][colw];
//                    System.out.println("data "+data[rom][data[rom].length-1]);
//                }
//                }
//                data[data.length-1][data[data.length-1].length-1]=0;//}
//             --j;
//                
//                c++;
//                }
//        }
//   
//    }
//    
//    
//  
//
//}


// الحذف مع التكرار بشرط ترك اخر قيمة 

// مصفوفة احادية تحذف مع التكرار ماعدى لبقيمة الاخير 
// والتحويل الى بداية المصفوفة 

public int [] deletiteam_arrayone(int[] data,int iteam){
// ابحث عن العنصر 
// اضع قيمة العنصر  يصفر 
//يخول العنصر  الى اخر شيء في المصفوفة 
int index=-1;
int c=0;
boolean found=false;
int sizse=data.length;   
for (int i = data.length-1; i >=0; i--) {
    if (data[i]==iteam) {
        if(c>=1){
    index=i;
    found=true;
    data[i]=0;
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
    //في هذه الحالى يحذف جميع البيانات التي تكررت ويضع بدلها صفر لكن الترتيب ليس تمام 
   for (int j = index; j <data.length-1; j++) {
          
      data[j]=data[j+1];
      
       System.out.print("  ==="+data[j]+"\t");   
   }
    data[data.length-1]=0;
    --i;
  //هذه صحيحة مئة بالمئة متبقي كيف احذ ف القيم الاخيرة كامل 
    }
    ++c;
    }
    }
    if (found) {
        // ناقص  واحد لانه اذاوقف عند العنصر الاخير ويريد الذي الذي بعده يطلع غلط 
        
    }else{
        System.out.println("element is not found :");
    }
return data;
}
// حذف مع التكرار بشرط ترك القيمة الاخير 
// بإستخدام ثلاث دوال النتحول من مصفوفة ثنائية الى احادية 
// الحذف مع ترك القيمة الاخير المكررة بإستخدام المصفوفة الاحادية 
// التحول من الثانئية الى احادية 

public void delete_list(int iteam){
int arayteam[]=data_one_array();

int arraydelete[]=deletiteam_arrayone(arayteam,iteam);

    conversionToAraay2(arraydelete);// دالة التحويل 

}




// دالة تقوم بحذف العناصر المكررة بإستخدام arraylist
//التحول من مصفوفة ثنائية الى arraylist 
// حذف العتاصر المكررة  بإستخدام ARRAtylist
// التحول من arraylist  الى المصفوفة الثنائية

AraayDg1 arraylist=new AraayDg1<Integer>();
public void a(){
 arraylist.converting2(data);
// القيمة المحولة الى مصفوفة ثنائية 
System.out.println("ENTER  TEHE ITEAM DETLE");
//  الحذف مع التكرر 
 Object arr[]=arraylist.deletiteam1(3);
 // احتفظ بعناصر المصفوفة الاحادية بوسطه  لانها من نوع جبنرك 
 // لا تستطيع حفظها في مصفوفة مباشرة من نوع اينint 
int count=0;
    for (int i = 0; i < data.length; i++) {
        for (int j = 0; j < data[i].length; j++) {
            if (count<=data.length) {
                data[i][j]= (int) arr[count];
                count++;
            }else{
  //  القيم المحذوفة اعملها بصفر           
            data[i][j]=0;
            }
        }
    }
    //  طباعة العناصر 
display();

}


}