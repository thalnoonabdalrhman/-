
package Array;

import java.util.Scanner;

public class Arraymain {

    public static void main(String[] args) {
        System.out.println("view the data :");
       byte opreation; 
       Scanner sc=new Scanner (System.in);
       AraayD1 AR=new AraayD1();
       ArrayD2 AR2=new ArrayD2();
      
       
        do { 
            System.out.println("1_Enter the matrix to ArrayD1: ");
            System.out.println("2_Enter th martix to ArrayD2 :");
            opreation=sc.nextByte();
            switch (opreation) {
                case 1:
                    boolean found =true;
                    do {                        
                        
                    System.out.println("1- Enter data into a ArrakyD1  martix :");
                  System.out.println("2- disply data into ArrayD1 matrix :");
                    System.out.println("3- Delet the  from  the matrix :");
                        System.out.println("4- في حالة تريد الخروج من هنا إضغط 0");
                        switch (opreation=sc.nextByte()) {
                            case 1:
                                System.out.println("Enter the sizes :");
                                AR.insert();
                                System.out.println("enter th iteam delete ");
                                AR.deletiteam_whith_r_lestE_to_thelast(new Scanner(System.in).nextInt());
                               // AR.delet_2(2);
                                // حذف بشرط ترك اول قيمة واخر قيمة 
//                                System.out.println("enter etieam the delete ");
//                                AR.deleteiteamfirsr_list(new Scanner(System.in).nextInt());
                                break;
                                case 2:
                                AR.display();
                                break;
                                case 3:
                               int o;     
                    while(opreation==3){
                    System.out.println("1- Delet without repetition");//بدون التكرار 
                    System.out.println("2- Delet with repetition");//مع التكرار 
                    
System.out.println("3- Delet with repetition with  the first  value exceeding :");//حذف مع تخطي اول قيمة 
System.out.println("4- Delet with repetition with  the seconed   value exceeding :");// حذف مع تخطي ثاني قيمة 
System.out.println("5- Delet with repetition with  the first  value exceeding the last  :");// حذف مع تخطي اول قيمة من الاخير 
//System.out.println("6- Delet with repetition with  the second  value exceeding the last :");// حذف مع تخطي ثاني قيمة من الاخير 
System.out.println("في حالة تريد العودة إضغط صفر 0 ");                       
System.out.println("6- display()");
switch (o=sc.nextByte()) {
                            case 1:
                                
                                 AR.deletiteam_wthiout_re(sc.nextInt());
                               AR.display();
                                break;
                                case 2:
                                
                                 AR.deletiteam1_whith_re(sc.nextInt());
                                 AR.display();
                                break;
                                case 3:
                                    AR.deletiteam3_whit_r_1(sc.nextInt());
                                break;
                                case 4:
                    AR.deletiteam_whit_r_2(sc.nextInt());
                                break;
                                case 5:
                            AR.deletiteam4_whit_r_lastE(sc.nextInt());
                                break;
                                case 6:
                      AR.display();
                      break;
                            default:
                               
                         opreation=1;
                        }
                    
                    }
                                
                                break;
                            default:
                                found=false;
                                System.out.println("------------------------------");
                        }
                    
                    
                    } while (found);

                    break;
                case 2:
             boolean found1=true;
             do{
                     System.out.println("1- Enter data into a ArrakyD2  matrix :");
                     System.out.println("2- disply data into ArrayD2 matrix :");
                    System.out.println("3- Delet the  from  the matrix :");
                    System.out.println("4-  في حالة تريد الخروج إضغط صفر ");
                 switch (opreation=sc.nextByte()) {
                     case 1:
                         //System.out.println("ENTER the row :");
                         //int ro=sc.nextInt();
                       //  System.out.println("Enter the col :");
                     //int co=sc.nextInt();
                   //   AR2.init(ro, co);//إضافة الحجم 
                      
                        AR2.insert(2);
                        AR2.insert(3);
                        AR2.insert(23);
                        AR2.insert(3);
                        AR2.insert(3);
                        AR2.insert(3);
                        AR2.insert(2);
                        AR2.insert(2);
                     AR2.a();
//                         System.out.println("ente the delete ");
//                        AR2.delete_l(new Scanner(System.in).nextInt())
                   break;
                         case 2:
                         AR2.display();
                 System.out.println("ente the delete ");
//         AR2.delete_list(new Scanner(System.in).nextInt());;

                         break;
                         case 3:
                             int p;
                             while (opreation==3) {                                 
         System.out.println("1- Delet without repetition");//بدون التكرار 
         System.out.println("2- Delet with repetition");//مع التكرار 
          System.out.println("3- Delet with repetition the latest conversion ArrayD1 :");//مع التكرار  مع التحويل الى الاخير بإستخدام المصفوفة احادية
          System.out.println("4- Delet with repetition the latest conversion ArrayD2 :");//مع التكرار  مع التحويل الى الاخير بإستخدام مصفوفة ثنائية 

System.out.println("5- Delet with repetition with  the first  value exceeding :");//حذف مع تخطي اول قيمة 
System.out.println("6- Delet with repetition with  the seconed   value exceeding :");// حذف مع تخطي ثاني قيمة 
System.out.println("7- display ");
                                 System.out.println(" الخروج من العملية ");
//System.out.println("5- Delet with repetition with  the first  value exceeding the last  :");// حذف مع تخطي اول قيمة من الاخير 
//System.out.println("6- Delet with repetition with  the second  value exceeding the last :");// حذف مع تخطي ثاني قيمة من الاخير
                                 switch (p=sc.nextByte()) {
                                     case 1:
                 AR2.deletiteamt_without_re(sc.nextInt());    
                                         break;
                                         case 2:
                 AR2.deletiteam3_wiht_r(sc.nextInt());   
                                         break;
                                         case 3:
           AR2.deletiteam_with_r_use_3_function(sc.nextInt());   
                                         break;
                                         case 4:
                AR2.deletiteam4_use_2D(sc.nextInt());   

                                             
                                         break;
                                         case 5:
                 AR2.deletiteam5_with_r_1(sc.nextInt());   
                                         
                                         break;
                                         case 6:
                                             System.out.println("****************");
                                         break;
                                         case 7:
                                         AR2.display();
                                         break;
                                        
                                     default:
                                         System.out.println("eixt 0"); 
                                     opreation=1;
                                 }
                             }
                             
                             break;
                              case 4:
                                    found1=false;

                                  
                            break;
                            case 5:
                         System.out.println("000o");
                            AR2.deletiteaminqueue();
                         break;
                     default:
                       System.out.println("REALY :");    
                 } 
             }while(found1);
                     break;
                default:
                
                
            System.out.println("REALY :");            }
        } while (true);
    }
     
}
