/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Array;

import java.util.Scanner;
import gArray.AraayDg1;
public class AraayD1 {

    int[] data;
    int cruntpostion;
    public int length;

 public   AraayD1 (int sizes) {
        data = new int[sizes];
     cruntpostion=-1;
    }
    
   public AraayD1() {
       
        this.data = new int [6];
        cruntpostion=-1;
//عملت كسنج لتحويلها من نوع مصفوفة 
//ال نوع جينرك 
    }
   boolean isempty(){
   return cruntpostion==-1;
   }
   boolean isfull(){
   return cruntpostion==data.length-1;
   }
    
//   public int lenghth(){
//   return data.length;
//   }
// دالة إدخال 
    public void insert() {
        if (isfull()) {
            System.out.println("is full"); 
        return;
        }
        for (int i = 0; i < data.length; i++) {
                    data[++cruntpostion]=new Scanner(System.in).nextInt();

        }
    }
// دالة الطباعة 
public void display() {
        if (isempty()) {
            System.out.println("isempty ");
        return;
        }
        System.out.println("araay elemen the are  :");
        for (int i = 0; i < cruntpostion; i++) {
            System.out.println(data[i] + "\t");
        }

        
    }
  // دالة الحذف بدون تكرار1  
    
   //تحذف اول قيمة من اول المصفوفة وجدها حتى لو وجد تكرارت مارح يحذف التكرارت
int[] deletiteam_wthiout_re(int iteam){
// ابحث عن العنصر 
// اضع قيمة العنصر  يصفر 
//يخول العنصر  الى اخر شيء في المصفوفة 
int index=-1;
boolean found=false;
   if (isempty()) {
            System.out.println("isempty ");
        return null;
        }
for (int i = 0; i <cruntpostion; i++) {
    if (data[i]==(iteam)) {
    index=i;
    found=true;
    data[i]=0;// لانها رجعت من نوع جينرك 
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
        break;
        
    }
    
    }
    if (found) {
        // ناقص  واحد لانه اذاوقف عند العنصر الاخير ويريد الذي الذي بعده يطلع غلط 
        for (int i = index; i <cruntpostion-1; i++) {
         data[i]=data[i+1];
        }
            cruntpostion--;// بنقص حجم المصفوفة 
        data[cruntpostion-1]=0;
    }else{
        System.out.println("element is not found :");
    }
return data;
}

   
//في حالة اريد ان احذف مع التكرار 
// اخلي اول قيمة واحذف التكرارت
// الحذف مع التكرار بشرط ان نترك العنصر الاول من التكرار 

void deletiteam1_whith_re(int iteam){
// ابحث عن العنصر 
// اضع قيمة العنصر  يصفر 
//يخول العنصر  الى اخر شيء في المصفوفة 

if (isempty()) {
            System.out.println("isempty ");
        return;
        }
int index=-1;
int c=0;
boolean found=false;
int sizse=data.length;   
for (int i = 0; i <cruntpostion; i++) {
    if (data[i]==(iteam)) {
        if(c>=1){
    index=i;
    found=true;
    data[i]=0;
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
    //في هذه الحالى يحذف جميع البيانات التي تكررت ويضع بدلها صفر لكن الترتيب ليس تمام 
   for (int j = index; j <cruntpostion-1; j++) {
          
      data[j]=data[j+1];
      }
    data[cruntpostion-1]=0;
    // من اجل التأكد من القيمة الذي حولنها هل هيا نفسها 
      --i;
 //  i--;
  // sizse--;
  //هذه صحيحة مئة بالمئة متبقي كيف احذ ف القيم الاخيرة كامل 
    cruntpostion--;
    }
    c++;
    }
    }
    if (found) {
        // ناقص  واحد لانه اذاوقف عند العنصر الاخير ويريد الذي الذي بعده يطلع غلط 
       
    }else{
        System.out.println("element is not found :");
    }


}


// اريد مثلا اخر قيمة واحذف الذي قبهلا مكرر كامل 
//الحذف مع التكرار بشرط ان نترك اخر عنصر من التكرار 
void deletiteam4_whit_r_lastE(int iteam){
if (isempty()) {
       System.out.println("isempty ");
        return;
        }

// ابحث عن العنصر 
// اضع قيمة العنصر  يصفر 
//يخول العنصر  الى اخر شيء في المصفوفة 
int index=-1;
int c=0;
boolean found=false;
int sizse=data.length;   
for (int i = cruntpostion-1; i >=0; i--) {
    if (data[i]==(iteam)) {
        if(c>=1){
    index=i;
    found=true;
    data[i]=0;
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
    //في هذه الحالى يحذف جميع البيانات التي تكررت ويضع بدلها صفر لكن الترتيب ليس تمام 
   for (int j = index; j >0; j--) {
          
      data[j]=data[j-1];
      
       System.out.print("  ==="+data[j]+"\t");   
   }
    data[0]=0;
     --i;
     cruntpostion--;
  // sizse--;
  //هذه صحيحة مئة بالمئة متبقي كيف احذ ف القيم الاخيرة كامل 
    }
    ++c;
    }
    }
    if (found) {
        // ناقص  واحد لانه اذاوقف عند العنصر الاخير ويريد الذي الذي بعده يطلع غلط 
        
    }else{
        System.out.println("element is not found :");
    }


}
/// الحذف مع التكرار بشرط ترك ثاني قيمة من التكرارت
void deletiteam_whit_r_2(int iteam){
// ابحث عن العنصر 
// اضع قيمة العنصر  يصفر 
//يخول العنصر  الى اخر شيء في المصفوفة 
if (isempty()) {
            System.out.println("isempty ");
        return;
        }

int index=-1;

int c=1;
boolean found=false;
int sizse=data.length;   
for (int i = 0; i<cruntpostion; i++) {
    if (data[i]==(iteam)) {
        //  عددد التكرارات في حالة وجد اول مرة التكرار يكون بواحد بيدخل ويحذف في المرة الثانية 
  //بيزيد على التكرار بيكون اثنين بيقول هل الاثنين لا يساوي الاثنين  خطى مارح يدخل الحلقة المرة الثالثة بيزيد على قيمة التكار بيكون ثلاثة
        //الان بيجي يقارن وهيا هل الثلاثة لا تساوي الاثنين بيكون نعم بيدخل ويحذف وهكذا بعده يعني تعدي القيمة 
        if(c!=2){
    index=i;
    found=true;
    data[i]=0;
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
    //في هذه الحالى يحذف جميع البيانات التي تكررت ويضع بدلها صفر لكن الترتيب ليس تمام 
   for (int j = index; j <cruntpostion-1; j++) {
          
      data[j]=data[j+1];
      
       System.out.print("  ==="+data[j]+"\t");   
   }
    data[cruntpostion-1]=0;
    // من اجل يرحع خطوة للأمام من اجل التأكد 
    --i;
  // sizse--;
  //هذه صحيحة مئة بالمئة متبقي كيف احذ ف القيم الاخيرة كامل 
    cruntpostion--;
        }
    ++c;
    }
    }
    if (found) {
        // ناقص  واحد لانه اذاوقف عند العنصر الاخير ويريد الذي الذي بعده يطلع غلط 
        
    }else{
        System.out.println("element is not found :");
    }

}


void deletiteam3_whit_r_1(int iteam){
// ابحث عن العنصر 
// اضع قيمة العنصر  يصفر 
//يخول العنصر  الى اخر شيء في المصفوفة 
if (isempty()) {
            System.out.println("isempty ");
        return;
        }

int index=-1;

int c=1;
boolean found=false;
int sizse=data.length;   
for (int i = 0; i<cruntpostion; i++) {
    if (data[i]==(iteam)) {
        //  عددد التكرارات في حالة وجد اول مرة التكرار يكون بواحد بيدخل ويحذف في المرة الثانية 
  //بيزيد على التكرار بيكون اثنين بيقول هل الاثنين لا يساوي الاثنين  خطى مارح يدخل الحلقة المرة الثالثة بيزيد على قيمة التكار بيكون ثلاثة
        //الان بيجي يقارن وهيا هل الثلاثة لا تساوي الاثنين بيكون نعم بيدخل ويحذف وهكذا بعده يعني تعدي القيمة 
        if(c<2){
    index=i;
    found=true;
    data[i]=0;
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
    //في هذه الحالى يحذف جميع البيانات التي تكررت ويضع بدلها صفر لكن الترتيب ليس تمام 
   for (int j = index; j <cruntpostion-1; j++) {
          
      data[j]=data[j+1];
      
       System.out.print("  ==="+data[j]+"\t");   
   }
    data[cruntpostion-1]=0;
    // من اجل يرحع خطوة للأمام من اجل التأكد 
    --i;
  // sizse--;
  //هذه صحيحة مئة بالمئة متبقي كيف احذ ف القيم الاخيرة كامل 
    cruntpostion--;
        }
    ++c;
    }
    }
    if (found) {
        // ناقص  واحد لانه اذاوقف عند العنصر الاخير ويريد الذي الذي بعده يطلع غلط 
        
    }else{
        System.out.println("element is not found :");
    }

}
// مصفوفة احادية تحذف مع التكرار ماعدى لبق
// مصفوفة احادية تحذف مع التكرار ماعدى لبقيمة الاخير 
// والتحويل الى بداية المصفوفة 

void deletiteam_whith_r_lestE_to_thelast(int iteam){
// ابحث عن العنصر 
// اضع قيمة العنصر  يصفر 
//يخول العنصر  الى اخر شيء في المصفوفة 
int index=-1;
int c=0;
boolean found=false;
int sizse=data.length;   
for (int i = data.length-1; i >=0; i--) {
    if (data[i]==(iteam)) {
        if(c>=1){
    index=i;
    found=true;
    data[i]=0;
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
    //في هذه الحالى يحذف جميع البيانات التي تكررت ويضع بدلها صفر لكن الترتيب ليس تمام 
   for (int j = index; j <data.length-1; j++) {
          
      data[j]=data[j+1];
      
     //  System.out.print("  ==="+data[j]+"\t");   
   }
    data[data.length-1]=0;
    --i;
  //هذه صحيحة مئة بالمئة متبقي كيف احذ ف القيم الاخيرة كامل 
    }
    ++c;
    }
    }
    if (found) {
        // ناقص  واحد لانه اذاوقف عند العنصر الاخير ويريد الذي الذي بعده يطلع غلط 
        
    }else{
        System.out.println("element is not found :");
    }


}

// دالة التحويل من تنائية الى احادية 
public  int[] converting2(int data[][]){
int array1iteam[]=new int [data.length*data[data.length-1].length];
// حجم الصف في حجم العمود
int count=0;
    for (int i = 0; i < data.length; i++) {
      for (int j = 0; j < data[i].length; j++) {
      array1iteam[count]=data[i][j];
         ++count; 
     }
    }
    
return array1iteam;
}


//في حالة اريد ان احذف مع التكرار 
// دالة الحذف مع التكرار2
public void deletiteam1(int iteam){
// ابحث عن العنصر 
// اضع قيمة العنصر  يصفر 
//يخول العنصر  الى اخر شيء في المصفوفة 


if (isempty()) {
            System.out.println("isempty ");
        return;
        }
int index=-1;
int c=0;
boolean found=false;
int sizse=data.length;   
for (int i = 0; i <cruntpostion; i++) {
    if (data[i]==(iteam)) {
    index=i;
    found=true;
    data[i]=0;
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
    //في هذه الحالى يحذف جميع البيانات التي تكررت ويضع بدلها صفر لكن الترتيب ليس تمام 
   for (int j = index; j <cruntpostion-1; j++) {
          
      data[j]=data[j+1];
      }
    data[cruntpostion-1]=0;

   --i;
 //  i--;
  // sizse--;
  //هذه صحيحة مئة بالمئة متبقي كيف احذ ف القيم الاخيرة كامل 
    cruntpostion--;
    }
    }
    if (found) {
        // ناقص  واحد لانه اذاوقف عند العنصر الاخير ويريد الذي الذي بعده يطلع غلط 
        
    }else{
        System.out.println("element is not found :");
    }


}

///////////////////////////////
//
// مصفوفة احادية تحذف مع التكرار ماعدى القينة المكررة اذا كانت اخر قيمة   
// والتحويل الى نهاية  المصفوفة 

public void  delet_list(int iteam){
// ابحث عن العنصر 
// اضع قيمة العنصر  صفر 
//يخول العنصر  الى اخر شيء في المصفوفة 
int index=-1;
int c=0;
boolean found=false;
int sizse=data.length;   
for (int i = data.length-1; i >=0; i--) {
    if (data[i]==(iteam)) {
        if(c>=1){
    index=i;
    found=true;
    data[i]=0;
   //حولت قيمة الموقع الى صفر 
   //بعده بكسر الحلقة 
    //في هذه الحالى يحذف جميع البيانات التي تكررت ويضع بدلها صفر لكن الترتيب ليس تمام 
   for (int j = index; j <data.length-1; j++) {
          
      data[j]=data[j+1];
      
      // System.out.print("  ==="+data[j]+"\t");   
   }
    data[data.length-1]=0;
    --i;
  //هذه صحيحة مئة بالمئة متبقي كيف احذ ف القيم الاخيرة كامل 
    }
    ++c;
    }
    }
    if (found) {
        // ناقص  واحد لانه اذاوقف عند العنصر الاخير ويريد الذي الذي بعده يطلع غلط 
        
    }else{
        System.out.println("element is not found :");
    }

}


    
   }
