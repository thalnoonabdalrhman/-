/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tree;

/**
 *
 * @author a
 * 
 */



/// المكاتب 
import java.util.Stack;
import java.util.Queue;
import java.util.LinkedList;
import java.lang.Math.*;
 class BinarysarchTree {
   tnode root;// الجذر 

    public BinarysarchTree() {
        root = null;
    }
   boolean isempay(){//  
   return root==null;
   
   
   }
   
   // دالة الإضافة 
                                                     //new node القيمة الجديدة 
   public void insert(tnode mainnode,tnode newnode ){// mainnode ==يعيني الروت الجذر الأساسي 
 //  تستلم الروت حق السجرة والقيمة الجديد  
   //
// في حالت كانت فاضية 
if (isempay()) {
    //بخزن القيمة
    // هذا البرنت الذي باضيف من شقه بيصبح اب 
 //هذا البرنت  الذي سوف اضيف من شقة وليس جذر الشجرة الاصل مفهوم 
 root=newnode;// اخر نود وصلت الى عندها 
   return;
       }
   //هنا البداية 
   if(newnode.getData()>mainnode.getData()){// التأكد  من القيمة هل القيمة المدخلة اكبر 
                                              // right التحرك في جانب اليمين 
       // بتجه في جهة اليمين 
// هل النود هذه تؤشر على فاضي مافيش قيمة 
// هل يوجد لها يمين في حالت نعم بيضل يستدعي الى في حالت طلع اليمين فاضي بعدها بيضيف 
 if(mainnode.hasright()){   // التأكد هل المجال مفتوح للإضافة 
//  بيضل يستدعي  الى عند تطلع المكان فاضي 

// بيضل يستدعي الى عند القيمة الفاضية 
insert(mainnode.getRight(), newnode);// الريكرجن
// بستدعي مع الدخول الى جهة اليمن 
}else{
 // يعني وجد حالت المكان الفاضي الان بيضيق القيمة 
 // بخزن القيمة في جهة اليسالر عند من شق الاب
 mainnode.setRight(newnode);//mainnode.right=newnode;// h]ogj hgrdlm fk[hp  
  // ألإحتفاظ بأب النود الجديد   
newnode.setParent(mainnode);// لاننه بتحتاجه في مكان اخرى 
 }
           //
   }else if (newnode.getData()<mainnode.getData()) {
          //  القيمة حق البرنت هل اقل 
          if (mainnode.haslift()) {
    // هل يوجد اتجاه يسار بيضل يمشي ويستدعي الى عندما اتجاه اليسار يكون فاضي 
    // بينتقل الى الذي بعده 
       
// بيضل يستدعي القيم ويتاكد الى عند اخر قية في المين نود في حالت كانت الذي بعدها فاضية بليغ الشرط وينتقل الى الالس 
             ///تم تطبيق مفهوم الريكرجن
insert(mainnode.getLift(), newnode);
// // بستدعي مع الدخول الى جهة اليسار 

          }else{
// هنا بيجي يضيف  القمية    في شق اليسار   
mainnode.setLift(newnode);///minan.light=newnode;
          // قيمة الإضافة تكون مخزنة في شق اليسار   
// بحتفظ بقيمة الاب الذي خزنة فيه القيمة 
newnode.setParent(mainnode);//
          }  
   }else{
// new data= root data
// incres counter 
   
   }
   }
   
   
//دالة الطباعة في ثلث  حلات  
//pre order
public void perorder(tnode r){
    if (r==null) {
      return;
    }
     
    //root-lift-rigth
System.out.print(r.getData()+"\t");//root
perorder(r.getLift());//le fgt
perorder(r.getRight());//right
}

///in order 
//تستقبل نسخة من الروت 
public void inorder(tnode r){
     if (r==null) {
      return;
    }
//light -root-rigth
inorder(r.getLift());
System.out.print(r.getData()+"\t");//root
inorder(r.getRight());

}
//post order 
public void postorder(tnode r){
if (r==null) {
      return;
    }
//lift-right-root 
postorder(r.getLift());//lift
    postorder(r.getRight());//right 
    System.out.print(r.getData()+"\t");// root
}

  
//الطباعة مستوى مستوى 
public void leveLorder(){
    if (root==null) {
        return;// تعني الشجرة فاضية ولا يوجد بها شيء تمام 
    }
// بخزن في الستاك العنوان حق الروت وليس قيمة 
//   بدخل الجزر اول مرة الى الكيو 
// لانه عامل دالة الإستقبال من نوع نود  بنفس الوقت بتكون تخزن مؤضر 
//Queue<tnode> queue=new LinkedList<>();
int counter=0;//  هذا عبارة عن عداد يعد على حسب الورقة لان مستوى اول 
// يوجد فيه ورقة مستوى ثاني يوجد فيه ورقتين مستوى ثالث يوجد فيه ثالث 
// بستخدم  قانون من اجل عند المسوى المحدد يطلع عدد الوراق يساوى الاوراق القيم الذي عديتها بينزل سطر 
// العدد هذا يعدد القيم في المستوى حتى ولو فاضية لان  الكيو تتأكد من القيم
// بس هذا من اجل يتوافق الشرط كانه عدد الاوراق من اجل انزل  سطر من بعد الطباعة  الطباعة تبقي تطبع طبعي ولا لها دخل بهذا 
// في حالت تم نزول السطر ضروري ارجع العدد بصفر لانه بيعد الوراق من الصفر الى عند العدد المحدد لهذه الاوراق في المستوى 

int n=0;
//  هذه من اجل قانون البور 2^n  هذه القانون الذي يحدد عدد الاورق  
//  المستوى صفر عدد الاوراق وحده بيكون اثنين اس صفر بيطلع واحد يعني ورقة والعدد في حالت 
//  إخراج القيمة من الكيو بيزيد واحد 
//  بيتساوي الواحد مع الواخد بينزل سطر 
// بعد النزول يرجع العدد بصفر 
//  بيزود على قيمة الان واحد يعني انتقل الى المسوى الثاني 
// وهكذا شرط النزول اخر الكود 
Queue<tnode> queue=new LinkedList<>();
queue.add(root);
System.out.println("");
while(!queue.isEmpty()){// في حالت كانت فاضية يعني طبع العناصر  وحذفها في نفس الوقت 
  // الان بعمل متغير اخزن فيه القيمة التي سوف احذفها من الكيو بس يكون يخمل عنوان النود 
// بحذف النود من اجل اطبعها وبعده اتاكد هل يوجد لها رايت ولفت 

tnode team=queue.poll();// حذف القيمة التي وسط الكيو 
counter++;
stack.push(team);

System.out.print(team.getData()+"\t");/// بطبع القيمة
// 

if (team.getLift()!=null) {
    queue.add(team.getLift());
    
    }
if (team.getRight()!=null) {
 queue.add(team.getRight());
 //   }
}
// بحدد متى يتزل سطر ثاني 
if(Math.pow(2,n)==counter){// بيتأكد من المستوى المستوى صفر الورفة واحدة العدد الذي عده العداد واحد بيتساوي بينزل سطر 
    // ويرجع العداد بصفر من اجل يعد عدد الأوراق في المستوى الثاني 
    //  البور او الاس بيزيد واحد ينتقل الى المستوى الثاني وهكذاء 
    
   // System.out.println("pow "+Math.pow(2, n));
    System.out.print("\n");
   // System.out.println(" successful");
  n=n+1;
counter=0;}
        }
}
    // السفر من العمق  القيم التي كنت ابطعها
  // في السفر على المستويات بخونها داخل stack
  // برجع اطبع من النهاية 
   Stack<tnode> stack=new Stack<>();
   
public void depht(){
    int counter=0;//  
    int n=0;
    Queue<tnode> queue=new LinkedList<>();
queue.add(root);
System.out.println("");
while(!queue.isEmpty()){// في حالت كانت فاضية يعني طبع العناصر  وحذفها في نفس الوقت 
  // الان بعمل متغير اخزن فيه القيمة التي سوف احذفها من الكيو بس يكون يخمل عنوان النود 
// بحذف النود من اجل اطبعها وبعده اتاكد هل يوجد لها رايت ولفت 

tnode team=queue.poll();// حذف القيمة التي وسط الكيو 
stack.push(team);// تخزين القيم الستاك
// 
// 

if (team.getLift()!=null) {
    queue.add(team.getLift());
   
    }
if (team.getRight()!=null) {
 queue.add(team.getRight());
 //   }

}}
    while (!stack.isEmpty()) {        
        System.out.print(stack.pop().getData()+"\t");
//        if(Math.pow(2,n)==counter){// بيتأكد من المستوى المستوى صفر الورفة واحدة العدد الذي عده العداد واحد بيتساوي بينزل سطر 
//    // ويرجع العداد بصفر من اجل يعد عدد الأوراق في المستوى الثاني 
//    //  البور او الاس بيزيد واحد ينتقل الى المستوى الثاني وهكذاء 
    
//   System.out.println("pow "+Math.pow(2, n));
//    System.out.print("\n");
//   System.out.println(" successful");
//      n=n-1;
//        }
        }
    


}
 


// دالة البحث عن اصغر قيمة 
public tnode getminmum(tnode r){
// في حلات ولا توجد قيمة 
if(r==null){
return null;// 
}
//  اصغر قيمة هيا في اليسار 
// في حالت لا يوجد يسار في الشجرة 
if(r.getLift()==null){
return r;//  تكون في هذه الحالة اصغر قيمة في الروت 

}
// اذاكان عندك يسار 
// بيضل يستدعي حتى تصير اليسار تساوي         
    
return getminmum(r.getLift());
}

// دالة البحث عن اكبر قيمة موجدة 
// تكون موجدة في اليمن 
public tnode getmaximum(tnode r){
 if(r ==null)
     return null;
 
    if (r.getRight()==null) {//  لايوجد عناصر في اليمين // الروت اكبر عنصر في الشجرة 
        return r;
    }
   //  بيستدعي الى عند القيمة المطلوبة 
 return getmaximum(r.getRight());
}


////// شغل المهندس 
public tnode getmin(tnode r){// العقدة لها ابنى في اليسار 
    ///نجيب اكبر قيمة في اليسار والاكبر في اليسار توجد في الجزءالايمن 
tnode t=r;// من اجل ابحث على اخر قيمة 
while(t.getRight()!=null){
t=getmin(r);// 
}
return r;
}

public tnode getmax(tnode r){
  //  العقدة لها ابنى في اليمين 
    ///نجيب اصغر قيمة في اليسار والاكبر في اليسار توجد في الجزءالايسر 
tnode t=r;//
while(t.getLift()!=null){
t=getmin(r);//  
}
return r;
}
















/// دالة الحذف 
public void deletevalue(int iteam,tnode mainnode){// tnode r  نسخة من الروت من اجل عمل مفهوم الريكرسف 
    // بس هذا المدخل تقدر تطبيق من خلاله مفهوه الريكرجن 
    
    if (mainnode==null) {
        return;// tree في حالة كانت فاضية 
    }
// التحقق 
if(iteam>mainnode.getData()){//  الدخول في في جهة اليمن والاستدعاء 
// هذه الامر في حالة تساوي القم لا يعمل لانه اكبر تمام  والشغل في حالت التساوي هو الحذف 
deletevalue(iteam, mainnode.getRight());//  بيرجع يستدعي في جهة اليمن مرة اخرى 
return;
}
    if (iteam<mainnode.getData()) { //  الدخول في جهة اليسار ويضل يستدعي الى حالت كانت القمة متساوية لا ينفذ الشرط 
 // هذه الامر في حالة تساوي القم لا يعمل لانه اكبر تمام  والشغل في حالت التساوي هو الحذف 
        deletevalue(iteam, mainnode.getLift());
return;
    }else
    {
    // اهم حالة وهيا حالت التساوي لانه يتم كل الشغل هنا 
    // الحذف على حالتين في حالت كانت 
        //1- ورقة 
        //2- اب 
         //   الورقة 
         // في حالت كانت لا يوجد له لا  يمنين ولا يسار //right=null and lift =null
    if(mainnode.isfree())// القيمة التي وقفت عندها 
    {// كاىنك وصلت الى عند لاخر شيء في الشجرة 
        // اليمن واليسار بنفس الوقت يكونو ب null
        //  انت واقف على الورقة اذاا ارجع خطوة الى عند الاب البرنت واعمل حذف
        //  في هذه الحالة يعمل شرطين هل ضروري يكون الاثنيين فاضيين والا ما ينفض الشرط 
    // انا كنت اخزن الاب جق كل ابناء الان انا وقف عند الابن واريد اشوف حقه الاب يعني برجع خطوةللخلف 
    // بخزن الاب في متغير من نوع نود 
    tnode team=mainnode.getParent();// بيرجع الى عند الابا 
    //  قبل الحذف هل هذه 
    // هل القيمة من بعد مارجعت الى عند الاب موجودة في اليمين او اليسار 
        if (team.getLift()==mainnode) {
            team.setLift(null);
            return;
        }
    team.setRight(null);
    }else if(mainnode.haslift()){// يوجد ابن في اليسار 
    tnode team=getmax(mainnode);
    mainnode.setData(team.getData());
    deletevalue(team.getData(), mainnode.getLift());
    
    }else if(mainnode.hasright()){
     tnode team=getmin(mainnode.getRight());
     mainnode.setData(team.getData());
        deletevalue(iteam, mainnode);
   
    
    
    }
    }

}


   
   
   
   }




