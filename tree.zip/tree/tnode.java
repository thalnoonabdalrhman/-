/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tree;

/**
 *
 * @author a
 */
 class tnode {
    private int data;
    private tnode right;
    private tnode lift;
    private tnode parent;// جذر كل اولاد //الاب 
    // العقد الاب لكل اثنين ابناء 

    public tnode() {
        right = lift = parent=null;
        data=data;
    }

    public tnode(int data) {
        this();
        this.data = data;
    }

    public int getData() {
        return data;
    }
// دوال set get 
    public void setData(int data) {
        this.data = data;
    }

    public tnode getRight() {
        return right;
    }

    public void setRight(tnode right) {
        this.right = right;
    }

    public tnode getLift() {
        return lift;
    }

    public tnode getParent() {
        return parent;
    }

    public void setParent(tnode parent) {
        this.parent = parent;
    }

    public void setLift(tnode light) {
        this.lift = light;
    }

    @Override
    public String toString() {
        return  "data=" + data ;
    }
// دوال
    // في حالت كان الريت فاضي 
    boolean hasright(){
    return right!=null;
    // بضل ابحث الى ان يلتغي هذ الشرط لان المكان الذي بأضيف فيه ضرور ي يكون فاضي 
    
    }
    // في حالت كان اللفت 
      boolean haslift(){
    return lift!=null;
    // بضل ابحث الى ان يلتغي هذ الشرط لان المكان الذي بأضيف فيه ضرور ي يكون فاضي 
    }  
 boolean isfree(){// في حالت  لا يوجد لها لا يمين ولا يسار 
 
 return (!haslift())&&(!hasright());// 
 }     
      
      
}

