/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tree;

import java.util.Scanner;

/**
 *
 * @author a
 */
public class maintree {
    
   public static void main(String[] arges){
  boolean found=true;
     BinarysarchTree t=new BinarysarchTree();

byte op;
       do { 
        System.out.println("1-  Enter th tree :");
        System.out.println("2-  print th preorder  :");
        System.out.println("3-  print th inorder ");
        System.out.println("4-  print th postorder  :");
        System.out.println("5-  Eprint th level order  :");
        System.out.println("6-  print th deth order  :");  
        System.out.println("7-  delet in tree  :");  
        System.out.println("8-  getminmum of tree  :");  
        System.out.println("9-  getmaxmum of tree  :"); 
        System.out.println("10- Enter exit");
           System.out.println("----");
           switch (op=new Scanner (System.in).nextByte()) {
               case 1:
 t.insert(t.root,new tnode(20));
 t.insert(t.root,new tnode(9));
  t.insert(t.root,new tnode(10));
  t.insert(t.root,new tnode(8));
  t.insert(t.root,new tnode(22));
  t.insert(t.root,new tnode(24));
    t.insert(t.root,new tnode(19));
    t.insert(t.root,new tnode(25));
                   break;
                   case 2:
    t.perorder(t.root);
  System.out.println("");
           
                   break;
                   case 3:
    t.inorder(t.root);
  System.out.println("");

               
                   break;
                   case 4:
 t.postorder(t.root);
System.out.println("");
                   break;
                   case 5:
  t.leveLorder();
                  
                   break;
                   case 6:
  t.depht();              
                  
                   break;
                   case 7:
  t.getmin(t.root);
                   break;
                   case 8:
t.getmax(t.root);
                   break;
                   case 9:
   t.deletevalue(20, t.root);
                   break;
                   case 10:
        found=false;           
                   break;
               default:
                   System.out.println("Retern ");           }
           
           
       } while (found);
       

       


    
   }
}
