/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stack1;

import java.util.Scanner;

public class main {

    //موقع التنفيذ 
    public static void main(String[] args) {
       int  i=0;
       byte op;
             stack_Array st=new stack_Array();
            linked_stack stack = new linked_stack();

boolean found1=true;
       do {   
            
            System.out.println("1-Enter the Array stack :");
            System.out.println("2-Enter the stack linked list:");
            System.out.println("3-Enter  to colse :");
            op=new Scanner(System.in).nextByte();//عملية إدخال 
            switch (op) {
               case 1:
                   boolean founds=true;
                   do {                       
                       System.out.println(" 1- Enter the iteam in stack from push :");
                      System.out.println(" 2-delet the iteam in stack from pop :");
                      System.out.println(" 3- view the iteam in stack from peek :");
                      System.out.println(" 4- display the iteam in stack  :");
                       System.out.println(" 5- delet the iteam to be usde by the user in stack from deletitem :");
                       System.out.println(" 6- DO you want to come back :");
                       switch (op=(new Scanner(System.in).nextByte())) {
                           case 1:
                             for ( i = 0; i < 10; i++) {
                                   System.out.print("Enter the iteam  -");
                                   st.push(new Scanner(System.in).nextInt());//ادخال مباشر 
                               }
                               break;
                               case 2:
                                   System.out.println("pop iteam "+st.peek());
                               break;
                               case 3:
                                   System.out.println("viwe top "+st.peek());
                               break;
                               case 4:
                                   st.display();
                                   //st.changvlaue(10, 5);
                              st.outvlaue();
                               break;
                               case 5:
                                   System.out.print("Enter the item to delet :-");
                                   st.deletiteam(new Scanner(System.in).nextInt());
                               break;
                               case 6:
                               founds=false;
                              break;
                           default:
                               System.out.println("Retry :");
                       }
                   } while (founds);
 
                   break;
                   case 2:
                     boolean  foundli=true;
                       
                       do {                           
    System.out.println(" 1- Enter the node  in stack from push :");
    System.out.println(" 2-delet the node in stack from pop :");
   System.out.println(" 3-display node in stack :");
    System.out.println(" 4- DO you want to come back :");
    switch (op=(new Scanner(System.in).nextByte())) {
          case 1:
              System.out.println("Enter node ");
              stack.push(new node(new Scanner(System.in).nextLine()));
              
              break;
              case 2:
              stack.pop();
              break;
          case 3:
              stack.displaystack();
              break;
              case 4:
              foundli=false;
              break;
          default:
                 System.out.println("Retry :");
      }
                       } while (foundli);
                   case 3:
                       found1=false;
                       break;
                       
      
            default:
                   System.out.println("Went out :");
            break;//للخروج 
            }
            
        } while (found1);
//      linked_stack stack = new linked_stack();
//        System.out.println("stack :");
//        stack.push(new node("ti")); 
//        stack.push(new node("uk"));
//        stack.push(new node("ol"));
//        stack.push(new node("pt"));
//        stack.displaystack();
//        System.out.println("delet stack :"+stack.pop().data);
//        System.out.println("etente th kkk");      
//        stack.push(new node("kkk"));
//
//      stack.displaystack();
//      
      /////////////////////////////////
      //دوال المصفوة 
//     // stack_Array st=new stack_Array();
//      st.push(8);
//      st.push(7);
//      st.push(6);
//      st.push(5);
//      st.push(3);
//      st.display();
//        System.out.println("stack is peek "+ st.peek());
//        System.out.println("stack is pop :" +st.pop());
//st.display();
//st.deletiteam(8);
//st.display();

     
    }

}
