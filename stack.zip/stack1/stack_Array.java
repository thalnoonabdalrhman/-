/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stack1;

import queue.qeueu_Array_liner;

/**
 *
 * @author a
 */
public class stack_Array {
   
////////تبع المحاضره 
//بإستخدام  المصفوفات 
int []data;
int top;
// الكنوستركتر
public stack_Array(){
data=new int[10];
top=-1;
}

public stack_Array(int sizes)
{
data=new int[sizes];
top=-1;
}
//function stack 
boolean isempty(){
return top==-1;
}

boolean isfull(){
  return top==(data.length-1);
//function push 
}
void push(int iteam){
   if(isfull()){
       System.out.println("stack is full ");
       return;
   }
data[++top]=iteam;
}

//function pop
int pop(){
if(isempty()){
        System.out.println("stack is empty ");
return -1;
}
return  data[top--]; //اولا بيرجع القيمة وبعدها بيحذف 

//بأخذ العنصر وبعدها بيحذفه مباشرة 
}
//function peek
int peek(){
if(isempty()){
    System.out.println("stack is empty :");
return -1;
}
return  data[top];//بيظهر ليا القيمة دون 
}

//function print
void display(){

    for (int i = top; i>=0; i--) {
        System.out.print(data[i]+" "+"--->");
    }
}

//delet itema condition 
//حذف قيمة محدده
void deletiteam(int  iteam){
if(isempty()){
    System.out.println("stack is empty ");
    return;}
    stack_Array sc=new stack_Array(top+1);// من اجل حصر العناصر على عدد العناصر المضافة مسبقة 
//    // هذه جديدة من اجل احذف من الاولة الى وسطها 
//    // القيم التي لا تساوي القيمة التي اريدها بحذفها الى وسط هذه 
//    // والقيم المساوية بخرجها الى مكان اخرى 
//    while (!isempty()) { 
//        if (peek()==iteam) {// برجع اخر موقع من الستاك ويجي يقارن 
//            // بيرجعها من دون حذف 
//            System.out.println(" تم الحذف "+"sucessfule delet :"+pop());  
//            //هنا حذفت من دون مالتقف القيمة 
//            break;//  في حالة تريد الحذف مع التكرار 
//            //ببعد هذه البرك 
//        }else{
//        //هنا حذفت الى وسط ستتاك جديده
//        //باجيب الساك الجديده واعمل لها بش  الى عنصر البب البب بتجع برمتر وسط البش 
//        sc.push( pop());
//        }
//        push(sc.pop());
//    }
//
//}

    for (int i = top; i >=0; i--) {
        if (data[i]==iteam) {// بقارن اخر عنصر مع العنصر الذي اريد ان احذفه 
          //في حالة نعم بحذفه فقط 
     System.out.println(" تم الحذف "+"sucessfule delet :"+pop());  // من الستاك الاولة 
          break;//حذف قيمة واحدة فقط 
        }else{
//في حالة لا بحذف من الستاك القديم الى الشتاك الجديد        
        sc.push(pop());// اضافة الى الجديد من دالة الحذف للأولة 
        }
    }
// الان كيف برجع القيم الى الستاك الاولة 
while(sc.top!=-1){    //while(!s.isempty()){//طريقة المهندس
// ادخال  الى الستاك من خلال دالة الحذف الستاك الجديدة 
push(sc.pop());
    System.out.println("oooo");
}   
//الغلط في خالة عمل التب حق الستاك الاولة رح يعتعبك لانه مارح يعمل شيء ويمكن يعمل لوب نهائي 

}

// دالة تقوم بتغيير كل القيمة المكررة الموجودة في stack
// قيم جديدة 

public void changvlaue(int oldval,int newval){

    if (isempty()) {
        return;
    }
   stack_Array sc=new stack_Array();
    while (!isempty()) {        
        if (peek()==oldval) {//  القيمة القديمة تساوي القيمة الذي على الستاك اغيرها
             pop();
            sc.push(newval);
            
        }else{
         sc.push(pop());
        }
    }
    while (!sc.isempty()) {
        push(sc.pop());
    }
 
   
}

/// دالة تقوم بإخراج القيم الزوجية الى طابور
public void outvlaue(){


    if (isempty()) {
        return;
    }
 stack_Array sc=new stack_Array();
qeueu_Array_liner aq=new qeueu_Array_liner();
    while (!isempty()) {        
        if (peek()%2==0) {
            aq.enqueue(pop());
        }else{
       sc.push(pop());
    }
    }
    while (!sc.isempty()) {        
        push(sc.pop());
    }
   display();
  aq.display();
}
}
