
package stack1;

 
public class linked_stack {
 // كلاس اللنكد استاك يتضمن مبدا الستاك 
// المبداء الذي يدخل اخيرا يخرج اولا
    
    node head;
    public linked_stack(){
    head=null;
    }
    
    boolean isempty(){
    return head==null;
    
    }
//    // دالة إضافة من النهاية 
//    
// void push(node st){
//if(isempty()){// في حالة كانت فارغة ولا يوجد شيء تعني إضافة للناهية 
//   head=st;// بدل ماكان فاضي رجع الان يحمل قيمة 
//   return;// بعدها بكسر الحلقة 
//}
//// في حالة كانت لسيت فاضي بتحرك الى الاخير 
//node team=head;
//while(team.next!=null){
//team=team.next;
//}
//team.next=st;
//// النود الخيرة التي كانت تؤشر على فاضي بربطها مع الجديدة المضافة
//    }
////  حذف من الاخير 
//node pop(){
//if(isempty())
//{
//    System.out.println("stack is empty :");
//return null;
//}
//node team=head;
//while(team.next.next!=null){
//// النود الذي قبل النود الااخيرة هل مؤشر النود الذي يؤشر على النود الاخيرة بنل 
//                        // في حالة تحقق الشرط بيخرج وهو حامل النود الذي قبل النود الاخيرة 
// team=team.next;
//}
//// احتفظ بالقيمة 
//node st=team.next;//القيمة الذي بحذفها بحتفظ بها 
//team.next=null;// حذفت القيمة 
//return st;// ارجاع القيمة المحذوفة 
//}
////دالة طباعة 
// 
// 
//////////////////////////////////////////////////////////
 //  الدوال التي يرديها الدكتور 
 

 public void push(node sth){
     if (isempty()) {
head=sth;
return;
     }
 sth.next=head;
 head=sth;
 }
public node pop(){
     if (isempty()) {
         System.out.println("stack is null ");
         return null;
     }
node teamval=head;//احذت العنصر مناجل ارجعه 
head=head.next;// عملت عملية الحذف هنا 
return teamval;//من اجل ان يرجه القيمة نفسها
}
public void displaystack(){
 node team=head;
     System.out.println(" stack :");
 while(team!=null){
     System.out.print(team.data+" -->"+" ");
 team=team.next;
 }
 System.out.println("null ");
 }

}
