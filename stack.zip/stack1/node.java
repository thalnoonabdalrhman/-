
package stack1;

public class node {
    //كلاس النود وفيه كل الأدوات 
    String data;//متغير بضع فيه قيمة البيانات 
    node next;//هذ اصل المؤشر
    // هذا  الكنوستركتر 
    public node(){
    next=null;// بوضع قبم اولية للمؤشر لانه اول مرة بيكون يشاور على null
    }
    public node(String data){
    this.data=data;// من اجل افرق مابين القيمة الذي قي الكلاس 
    // والبرميتر المرسل 
    //هذا يعتبر الحارس الاساسي لكل ابوجكت 
   this.next=null;
   
    }
    public node(String data,node next){
    this.data=data;
    this.next=next;
    
    } 
}
