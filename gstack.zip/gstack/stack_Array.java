/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gstack;

/**
 *
 * @author a
 */
public class stack_Array<t> {
   
////////تبع المحاضره 
//بإستخدام  المصفوفات 
t []data;
int top;
// الكنوستركتر
public stack_Array(){
data=(t[])new Object[12];
/// عملية كستنج تحويل 
top=-1;
}

public stack_Array(int sizes)
{
data=(t[])new Object[sizes];
top=-1;
}
//function stack 
boolean isempty(){
return top==-1;
}

boolean isfull(){
  return top==(data.length-1);
//function push 
}
void push(t iteam){
   if(isfull()){
       System.out.println("stack is full ");
       return;
   }
data[++top]=iteam;
}

//function pop
t pop(){
if(isempty()){
        System.out.println("stack is empty ");
return null;
}
return  data[top--]; //اولا بيرجع القيمة وبعدها بيحذف 

//بأخذ العنصر وبعدها بيحذفه مباشرة 
}
//function peek
t peek(){
if(isempty()){
    System.out.println("stack is empty :");
return null;
}
return  data[top];//بيظهر ليا القيمة دون 
}

//function print
void display(){

    for (int i = top; i>=0; i--) {
        System.out.print(data[i]+" "+"--->");
    }
}

//delet itema condition 
//حذف قيمة محدده
void deletiteam(t  iteam){
if(isempty()){
    System.out.println("stack is empty ");
    return;}
    stack_Array sc=new stack_Array(top+1);// من اجل حصر العناصر على عدد العناصر المضافة مسبقة 
//    // هذه جديدة من اجل احذف من الاولة الى وسطها 
//    // القيم التي لا تساوي القيمة التي اريدها بحذفها الى وسط هذه 
//    // والقيم المساوية بخرجها الى مكان اخرى 
//    while (!isempty()) { 
//        if (peek()==iteam) {// برجع اخر موقع من الستاك ويجي يقارن 
//            // بيرجعها من دون حذف 
//            System.out.println(" تم الحذف "+"sucessfule delet :"+pop());  
//            //هنا حذفت من دون مالتقف القيمة 
//            break;//  في حالة تريد الحذف مع التكرار 
//            //ببعد هذه البرك 
//        }else{
//        //هنا حذفت الى وسط ستتاك جديده
//        //باجيب الساك الجديده واعمل لها بش  الى عنصر البب البب بتجع برمتر وسط البش 
//        sc.push( pop());
//        }
//        push(sc.pop());
//    }
//
//}

    for (int i = top; i >=0; i--) {
        if (data[i].equals(iteam)) {// بقارن اخر عنصر مع العنصر الذي اريد ان احذفه 
          //في حالة نعم بحذفه فقط 
     System.out.println(" تم الحذف "+"sucessfule delet :"+pop());  // من الستاك الاولة 
          break;//حذف قيمة واحدة فقط 
        }else{
//في حالة لا بحذف من الستاك القديم الى الشتاك الجديد        
        sc.push(pop());// اضافة الى الجديد من دالة الحذف للأولة 
        }
    }
// الان كيف برجع القيم الى الستاك الاولة 
while(sc.top!=-1){    //while(!s.isempty()){//طريقة المهندس
// ادخال  الى الستاك من خلال دالة الحذف الستاك الجديدة 
push((t)sc.pop());// كستنج ترجع  من نوع جينرك
    System.out.println("oooo");
}   
//الغلط في خالة عمل التب حق الستاك الاولة رح يعتعبك لانه مارح يعمل شيء ويمكن يعمل لوب نهائي 
}
}
