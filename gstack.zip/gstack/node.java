
package gstack;

public class node<t> {
    //كلاس النود وفيه كل الأدوات 
    t data;//متغير بضع فيه قيمة البيانات 
    node next;//هذ اصل المؤشر
    // هذا  الكنوستركتر 
    public node(){
    next=null;// بوضع قبم اولية للمؤشر لانه اول مرة بيكون يشاور على null
    }
    public node(t data){
    this.data=data;// من اجل افرق مابين القيمة الذي قي الكلاس 
    // والبرميتر المرسل 
    //هذا يعتبر الحارس الاساسي لكل ابوجكت 
   this.next=null;
   
    }
    public node(t data,node next){
    this.data=data;
    this.next=next;
    
    } 
}
